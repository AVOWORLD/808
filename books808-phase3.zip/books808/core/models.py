from django.conf import settings
from django.db import models


class Currency(models.Model):
    code = models.CharField(max_length=3, primary_key=True)
    name = models.CharField(max_length=60)
    symbol = models.CharField(max_length=8, blank=True)

    class Meta:
        verbose_name_plural = "currencies"
        ordering = ["code"]

    def __str__(self):
        return self.code


class Entity(models.Model):
    """A legal entity with its own books (a company or country subsidiary)."""

    name = models.CharField(max_length=120)
    country = models.CharField(max_length=2, help_text="ISO 3166 alpha-2, e.g. MW")
    base_currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "entities"
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.country}, {self.base_currency_id})"


class ExchangeRate(models.Model):
    """Rate to convert one unit of `currency` into `to_currency` on a date."""

    currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="+")
    to_currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="+")
    date = models.DateField()
    rate = models.DecimalField(max_digits=18, decimal_places=6)

    class Meta:
        ordering = ["-date"]
        constraints = [
            models.UniqueConstraint(fields=["currency", "to_currency", "date"], name="uniq_rate_per_day"),
        ]

    def __str__(self):
        return f"1 {self.currency_id} = {self.rate} {self.to_currency_id} on {self.date}"


class Membership(models.Model):
    """A user's role inside one entity. Roles follow the concept doc:
    anyone submits, a finance lead approves (posts), founders see everything."""

    VIEWER = "viewer"
    SUBMITTER = "submitter"
    FINANCE = "finance"
    ADMIN = "admin"
    ROLES = [
        (VIEWER, "Viewer (read only)"),
        (SUBMITTER, "Submitter (create drafts)"),
        (FINANCE, "Finance (approve and post)"),
        (ADMIN, "Admin (finance plus setup)"),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="memberships")
    entity = models.ForeignKey(Entity, on_delete=models.CASCADE, related_name="memberships")
    role = models.CharField(max_length=10, choices=ROLES, default=VIEWER)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user", "entity"], name="uniq_membership")]

    def __str__(self):
        return f"{self.user} - {self.entity.name} - {self.role}"

    @property
    def can_submit(self):
        return self.role in (self.SUBMITTER, self.FINANCE, self.ADMIN)

    @property
    def can_post(self):
        return self.role in (self.FINANCE, self.ADMIN)
