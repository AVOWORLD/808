"""Create the starter data for the Malawi entity.

The chart of accounts below is a PLACEHOLDER so the system can run end to end.
It is meant to be replaced by the accountant's Malawi template.
Exchange rates are intentionally not seeded: add real ones in the admin.
"""

from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.management.base import BaseCommand

from core.models import Currency, Entity, Membership
from ledger.models import Account

CURRENCIES = [
    ("MWK", "Malawian kwacha", "MK"),
    ("USD", "US dollar", "$"),
    ("ZAR", "South African rand", "R"),
    ("KES", "Kenyan shilling", "KSh"),
    ("MZN", "Mozambican metical", "MT"),
]

# (code, name, type, parent code, postable)
CHART = [
    ("1000", "Assets", "asset", None, False),
    ("1010", "Bank - main account", "asset", "1000", True),
    ("1020", "Mobile money", "asset", "1000", True),
    ("1100", "Accounts receivable", "asset", "1000", True),
    ("1200", "Stockpile inventory", "asset", "1000", False),
    ("1210", "Stockpile inventory - at cost", "asset", "1200", True),
    ("1220", "Stockpile valuation adjustment (NRV)", "asset", "1200", True),
    ("1300", "VAT input receivable", "asset", "1000", True),
    ("2000", "Liabilities", "liability", None, False),
    ("2010", "Accounts payable", "liability", "2000", True),
    ("2100", "VAT output payable", "liability", "2000", True),
    ("2200", "Accrued expenses", "liability", "2000", True),
    ("3000", "Equity", "equity", None, False),
    ("3010", "Share capital", "equity", "3000", True),
    ("3020", "Retained earnings", "equity", "3000", True),
    ("4000", "Income", "income", None, False),
    ("4010", "Pilot and project fees", "income", "4000", True),
    ("4020", "Subscription revenue", "income", "4000", True),
    ("4100", "Stockpile revaluation gain", "income", "4000", True),
    ("4900", "Foreign exchange gain", "income", "4000", True),
    ("5000", "Expenses", "expense", None, False),
    ("5010", "Cloud and software", "expense", "5000", True),
    ("5020", "Contractors", "expense", "5000", True),
    ("5030", "Travel", "expense", "5000", True),
    ("5040", "Data and survey costs", "expense", "5000", True),
    ("5050", "Legal and registration", "expense", "5000", True),
    ("5060", "Bank charges", "expense", "5000", True),
    ("5100", "Stockpile revaluation loss", "expense", "5000", True),
    ("5900", "Foreign exchange loss", "expense", "5000", True),
]


class Command(BaseCommand):
    help = "Seed currencies, the Malawi entity and a placeholder chart of accounts."

    def add_arguments(self, parser):
        parser.add_argument("--admin-username")
        parser.add_argument("--admin-password")

    def handle(self, *args, **opts):
        for code, name, symbol in CURRENCIES:
            Currency.objects.get_or_create(code=code, defaults={"name": name, "symbol": symbol})

        entity, _ = Entity.objects.get_or_create(
            name="808 Computing Malawi", defaults={"country": "MW", "base_currency_id": "MWK"}
        )

        by_code = {}
        for code, name, type_, parent, postable in CHART:
            acct, _ = Account.objects.get_or_create(
                entity=entity,
                code=code,
                defaults={
                    "name": name,
                    "type": type_,
                    "parent": by_code.get(parent),
                    "is_postable": postable,
                },
            )
            by_code[code] = acct

        username, password = opts["admin_username"], opts["admin_password"]
        if username and password:
            User = get_user_model()
            user, created = User.objects.get_or_create(username=username, defaults={"is_staff": True, "is_superuser": True})
            if created:
                user.set_password(password)
                user.save()
            Membership.objects.get_or_create(user=user, entity=entity, defaults={"role": Membership.ADMIN})

        self.stdout.write(self.style.SUCCESS(f"Seeded {entity} with {len(CHART)} accounts."))
        call_command("seed_billing", stdout=self.stdout)
        call_command("seed_expenses", stdout=self.stdout)
