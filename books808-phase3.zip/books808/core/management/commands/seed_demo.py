"""Post a small set of clearly labelled DEMO journals so the charts have something to show.

Sample numbers only (MWK). Not real accounting data: run it on a development database.
"""

from datetime import date

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError

from core.models import Currency, Entity
from ledger import services
from ledger.models import Account, Journal

# (date, memo, debit code, credit code, amount)
DEMO = [
    (date(2026, 7, 1), "Share capital paid in", "1010", "3010", "20000000"),
    (date(2026, 7, 15), "Pilot fee received", "1010", "4010", "6000000"),
    (date(2026, 8, 10), "Cloud hosting", "5010", "1010", "900000"),
    (date(2026, 8, 20), "Subscription revenue", "1010", "4020", "4500000"),
    (date(2026, 9, 5), "Survey data purchase", "5040", "1010", "1200000"),
    (date(2026, 9, 30), "Stockpile recognised at cost", "1210", "2010", "3000000"),
    (date(2026, 10, 10), "Contractor payments", "5020", "1010", "1500000"),
    (date(2026, 10, 31), "Stockpile survey: write-down to NRV", "5100", "1220", "330000"),
]


class Command(BaseCommand):
    help = "Post sample DEMO journals for the Malawi entity (development only)."

    def add_arguments(self, parser):
        parser.add_argument("--username", required=True, help="A finance or admin user in the Malawi entity.")

    def handle(self, *args, **opts):
        user = get_user_model().objects.filter(username=opts["username"]).first()
        entity = Entity.objects.filter(name="808 Computing Malawi").first()
        if user is None or entity is None:
            raise CommandError("Run seed_malawi first and pass an existing --username.")
        if Journal.objects.filter(entity=entity, source="demo").exists():
            self.stdout.write("Demo journals already exist; nothing to do.")
            return
        mwk = Currency.objects.get(code="MWK")
        accounts = {a.code: a for a in Account.objects.filter(entity=entity)}
        for when, memo, dr, cr, amount in DEMO:
            journal = services.create_draft(
                entity=entity,
                user=user,
                date=when,
                memo=f"DEMO: {memo}",
                source="demo",
                lines=[
                    {"account": accounts[dr], "currency": mwk, "debit": amount},
                    {"account": accounts[cr], "currency": mwk, "credit": amount},
                ],
            )
            services.post_journal(journal, user)
        self.stdout.write(self.style.SUCCESS(f"Posted {len(DEMO)} demo journals."))
