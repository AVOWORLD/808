from .models import Membership


class ActiveEntityMiddleware:
    """Attach request.membership (the user's role in the entity they are working in).

    The active entity is kept in the session. Users only ever see entities they
    hold a membership for, which is the first layer of data isolation that the
    multi-tenant rollout will build on.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.membership = None
        user = getattr(request, "user", None)
        if user is not None and user.is_authenticated:
            memberships = list(user.memberships.select_related("entity", "entity__base_currency"))
            wanted = request.session.get("entity_id")
            chosen = next((m for m in memberships if m.entity_id == wanted), None)
            if chosen is None and memberships:
                chosen = memberships[0]
                request.session["entity_id"] = chosen.entity_id
            request.membership = chosen
            request.all_memberships = memberships
        return self.get_response(request)
