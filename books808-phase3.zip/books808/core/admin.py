from django.contrib import admin

from .models import Currency, Entity, ExchangeRate, Membership

admin.site.register(Currency)
admin.site.register(Entity)
admin.site.register(ExchangeRate)
admin.site.register(Membership)
