def entities(request):
    membership = getattr(request, "membership", None)
    return {
        "membership": membership,
        "active_entity": membership.entity if membership else None,
        "all_memberships": getattr(request, "all_memberships", []),
    }
