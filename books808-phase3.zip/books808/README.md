# 808 Books — phases 1 to 3

Django + Postgres foundation for 808 Computing's bookkeeping platform. Phase 1 covers the pieces the concept doc lists as the foundation and internal v1 core: entities, currencies, roles, chart of accounts, and a double-entry ledger with draft → post → reverse, plus a trial balance and an audit log. Phase 2 adds invoices, supplier bills, payments, contacts, tax rates and an aging report on top of it. Phase 3 adds expense claims (with receipts and approval) and budgets with a budget-vs-actual report.

## Run it

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_malawi --admin-username <you> --admin-password <a-strong-password>
python manage.py runserver
```

Open http://127.0.0.1:8000 and log in. Run the tests with `python manage.py test`.

**Updating an existing install?** After unzipping over it, run `python manage.py migrate`, then `python manage.py seed_billing` and `python manage.py seed_expenses` (both safe to repeat). They link billing and expenses to your chart and add starter tax rates.

To see the analytics charts with sample data (development only, invented MWK numbers labelled DEMO), run `python manage.py seed_demo --username <you>` after seeding. For sample customers, invoices, a bill and a part-payment (so the aging report has data), also run `python manage.py seed_demo_billing --username <you>`. For a sample budget and expense claims, run `python manage.py seed_demo_planning --username <you>` last.

SQLite is used by default so it runs anywhere. For Postgres set `DB_ENGINE=postgres` with `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`. Also set `DJANGO_SECRET_KEY` and `DJANGO_DEBUG=0` outside local development.

## What is in it

| Area | What it does |
| --- | --- |
| `core` | Currency, Entity (one set of books per legal entity, with a base currency), ExchangeRate, Membership (user role per entity: viewer, submitter, finance, admin) |
| `ledger` | Account (chart of accounts), Journal and JournalLine (multi-currency, balanced in the entity's base currency), AuditLog |
| `ledger/services.py` | All business rules: create draft, post, reverse, trial balance. Views never write journals directly |
| `ledger/analytics.py` | Plotly figures built from posted journals: income and expenses by month, stockpile inventory value over time (accounts under 1200) |
| `billing` | Contact (customer or supplier), TaxRate, Document (an invoice or a bill, with lines), Payment and PaymentAllocation, BillingSettings (which ledger accounts billing posts to) |
| `billing/services.py` | All billing rules: create, issue, record payment, void, delete draft, aging. Every money movement goes through the ledger services, so it is balanced, role-checked and audited |
| `expenses` | Expense (a claim with category, tax, optional receipt, who paid), ExpenseSettings (the liability account for money owed to staff) |
| `expenses/services.py` | Submit, approve (posts to the ledger), reject, reimburse, void, withdraw |
| `budgets` | Budget (twelve months from a start month) and BudgetLine (account x month amounts). Plans only: nothing posts to the ledger |
| `budgets/services.py` | Create budgets, add and remove accounts, yearly amount spread, save the grid, and the budget-vs-actual report |
| Screens | Expenses (list, submit, approve or reject, reimburse), budgets (monthly grid, budget vs actual with charts), invoices, bills (list, create, detail with issue, pay and void), contacts, receivables and payables aging. Plus: dashboard, analytics page, chart of accounts, journal list, new journal, journal detail (post, reverse, delete draft), trial balance, entity switcher |

## Rules built in

- Anyone with the submitter role can draft; only finance or admin can post.
- A journal must balance in the base currency, have at least two lines, and post only to active, non-header accounts of its own entity.
- Posted journals can't be edited or deleted. Mistakes are corrected with a reversing journal.
- Foreign-currency lines use the latest stored exchange rate on or before the journal date. Rates are not seeded: add real ones in the admin (`/admin/`).
- Every create, post, reverse and delete is written to an append-only audit log.
- Users only see entities they hold a membership for.

## Billing rules

- Submitters create draft invoices and bills; only finance or admin can issue them or record payments.
- Issuing assigns the next number per entity and kind (INV-0001, BILL-0001), fixes the exchange rate, and posts one journal: an invoice debits receivable and credits income and output VAT; a bill debits expense (or an asset, for example stockpile purchases) and input VAT and credits payable.
- Issued documents are locked. A mistake is fixed by voiding (which reverses the journal), then creating a new document. A document with payments can't be voided until its payments are voided.
- A payment is in the document's currency and can't exceed the outstanding balance. If the exchange rate differs from the document's, the difference posts to the FX gain or loss account. The same account absorbs sub-cent rounding on foreign-currency documents.
- Invoices post to income accounts only; bills post to expense or asset accounts.
- Which ledger accounts billing uses (receivable, payable, VAT, FX) is set per entity under Billing settings in the admin, so the accountant's chart can replace the starter one with no code changes.

## Expense rules

- Anyone who can submit creates a claim: date, description, expense category, the full receipt amount, the tax rate on it, who paid, and an optional receipt. The tax part is worked out from the total (amount x rate / (100 + rate)).
- Receipts must be PDF, JPG or PNG up to 5 MB, and the file content must match its type. They are stored under `media/` with random names and are **not** public: they are served only through a login-checked page, and submitters can open only their own.
- Submitters see only their own claims. Finance, admin and viewers see all claims in the entity.
- Finance or admin approves or rejects (rejection needs a reason). Finance-role users can't approve their own claims; admins can, so a small team can still work.
- Approving posts one journal: expense (net) and input VAT debited, and credited either to the "owed to staff" account (out-of-pocket claims) or to the company bank/card account chosen at approval (company-paid).
- Reimbursing an out-of-pocket claim debits what is owed to staff and credits the bank, in the entity's base currency at the rate fixed on approval.
- Voiding follows the same order as it was built: void the reimbursement first, then the expense. Journals created by invoices, bills, payments and expenses can't be reversed on their own from the Journals page; the owning document's void does it, so the two never disagree.

## Budget rules

- A budget is twelve months starting from the month you choose, so it can follow Malawi's financial year (the start month is yours to set, nothing is assumed). Amounts are positive numbers for both income and expense accounts, in the base currency.
- Everyone in the entity can view budgets; only finance and admin can create or change them.
- Budget vs actual compares the budget with posted journals only, year to date through a month you pick. Drafts and anything outside the budget period are ignored; reversals net out.
- Variance is favourable when income is above budget or expenses are below it. Activity on an account that has no budget line is shown as "Not budgeted" instead of being hidden.

Charts are drawn with Plotly.js loaded from `cdn.plot.ly`, so the browser needs internet access for them. Figures are built in Python (`plotly` package), so moving them into a mounted Dash app later is a small step.

## Placeholders to replace

- The chart of accounts in `core/management/commands/seed_malawi.py` is a **starter placeholder**. Replace it with the accountant's Malawi template.
- Stockpile accounts exist (`1210` at cost, `1220` valuation adjustment, `4100`/`5100` revaluation gain and loss) but nothing posts to them automatically yet. That comes with the valuation model the accountant defines.
- **The VAT rate is a placeholder** (16.5% in `seed_billing.py`, named "placeholder rate - confirm"). The accountant must confirm the correct rates, and which items are zero-rated or exempt, under Tax rates in the admin.
- Expenses owed to staff post to account `2200` (Accrued expenses) as a placeholder. The accountant may prefer a dedicated 'staff reimbursements payable' account (change it under Expense settings in the admin).
- Whether input VAT on expenses is claimable depends on the receipt and the tax rules. The form lets the claimant pick the tax rate, and the approver should check it.
- Accounts, entities, exchange rates, tax rates, billing settings and expense settings are managed through the admin for now.

## Known limits

- Draft documents can't be edited, only deleted and recreated. Issued documents can't be edited, only voided.
- One payment covers one document from the screens (the data model already supports one payment across several documents).
- No credit notes, prepayments or overpayments, no PDF or email of invoices, and no recurring invoices yet.
- Foreign-currency balances are not revalued at period end; the aging report shows them at their issue-date rate.
- The payment account is not tied to a currency, so choose the account that holds the payment currency.
- Expenses can't be edited after submission (withdraw and resubmit, or reject with a reason). Reimbursements are in the base currency.
- Budgets are by account and month only. The concept doc also asks for department, project and region; that needs tags on journal lines first, which the ledger doesn't have yet.
- No recurring expenses or recurring costs yet, and no approval limits (any finance user can approve any amount).
- Receipts live on the server's disk under `media/` (set `DJANGO_MEDIA_ROOT` to move it). Back that folder up together with the database.

## Not built yet (next)

Bank reconciliation, the Standard Bank Malawi payment integration, Strata survey → stockpile journals, and the multi-tenant hardening.
