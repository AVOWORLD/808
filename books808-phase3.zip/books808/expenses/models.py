import os
import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models

from billing.models import TaxRate
from core.models import Currency, Entity
from ledger.models import ZERO, Account, Journal, money


def receipt_path(instance, filename):
    ext = os.path.splitext(filename)[1].lower()
    return f"receipts/{instance.entity_id}/{uuid.uuid4().hex}{ext}"


class ExpenseSettings(models.Model):
    """The liability account that holds money owed back to staff who paid out of pocket."""

    entity = models.OneToOneField(Entity, on_delete=models.CASCADE, related_name="expense_settings")
    reimbursable_payable = models.ForeignKey(
        Account, on_delete=models.PROTECT, related_name="+", verbose_name="Amounts owed to staff (liability)"
    )

    class Meta:
        verbose_name_plural = "expense settings"

    def __str__(self):
        return f"Expense settings for {self.entity.name}"


class Expense(models.Model):
    SUBMITTED, APPROVED, REJECTED, REIMBURSED, VOID = "submitted", "approved", "rejected", "reimbursed", "void"
    STATUSES = [
        (SUBMITTED, "Submitted"), (APPROVED, "Approved"), (REJECTED, "Rejected"),
        (REIMBURSED, "Reimbursed"), (VOID, "Void"),
    ]
    CLAIMANT, COMPANY = "claimant", "company"
    PAID_BY = [(CLAIMANT, "I paid and need to be reimbursed"), (COMPANY, "Paid with a company account or card")]

    entity = models.ForeignKey(Entity, on_delete=models.PROTECT, related_name="expenses")
    submitted_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="expenses_submitted")
    date = models.DateField()
    description = models.CharField(max_length=255, help_text="What it was and who it was paid to.")
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+", verbose_name="Category")
    amount = models.DecimalField(max_digits=18, decimal_places=2, help_text="The full amount on the receipt, tax included.")
    currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="+")
    tax_rate = models.ForeignKey(TaxRate, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    net = models.DecimalField(max_digits=18, decimal_places=2, default=ZERO, editable=False)
    tax = models.DecimalField(max_digits=18, decimal_places=2, default=ZERO, editable=False)
    paid_by = models.CharField(max_length=10, choices=PAID_BY, default=CLAIMANT)
    receipt = models.FileField(upload_to=receipt_path, blank=True)
    status = models.CharField(max_length=12, choices=STATUSES, default=SUBMITTED)
    reject_reason = models.CharField(max_length=255, blank=True)
    fx_rate = models.DecimalField(max_digits=18, decimal_places=6, default=Decimal("1"), help_text="Fixed when approved.")
    paid_from = models.ForeignKey(Account, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    journal = models.OneToOneField(Journal, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    reimbursement_journal = models.OneToOneField(Journal, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    submitted_at = models.DateTimeField(auto_now_add=True)
    decided_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    decided_at = models.DateTimeField(null=True, blank=True)
    reimbursed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-date", "-id"]

    def __str__(self):
        return f"EXP-{self.pk:04d}" if self.pk else "New expense"

    def save(self, *args, **kwargs):
        rate = self.tax_rate.rate if self.tax_rate_id else Decimal("0")
        # The receipt amount includes tax, so the tax part is amount * rate / (100 + rate).
        self.tax = money(self.amount * rate / (Decimal("100") + rate)) if rate else ZERO
        self.net = self.amount - self.tax
        super().save(*args, **kwargs)

    @property
    def display_status(self):
        if self.status == self.APPROVED:
            return "awaiting reimbursement" if self.paid_by == self.CLAIMANT else "paid by company"
        return self.status
