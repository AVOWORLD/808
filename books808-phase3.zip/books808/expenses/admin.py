from django.contrib import admin

from .models import Expense, ExpenseSettings

admin.site.register(ExpenseSettings)


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    """Read-only: claims change only through the app, which keeps the ledger consistent."""

    list_display = ("__str__", "entity", "submitted_by", "date", "amount", "status")
    list_filter = ("entity", "status")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
