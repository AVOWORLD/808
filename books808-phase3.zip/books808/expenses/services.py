"""Expense claims: submit, approve (posts to the ledger), reject, reimburse, void.

All money movement goes through ledger.services. Approval is a separate step from submission, and
finance-role users can't approve their own claims (admins can, so a small team can still work)."""

from decimal import Decimal

from django.core.exceptions import ObjectDoesNotExist, PermissionDenied, ValidationError
from django.db import transaction
from django.utils import timezone

from billing import services as billing
from core.models import Membership
from ledger import services as ledger
from ledger.models import ZERO, Account, money

from .models import Expense, ExpenseSettings
from .validators import validate_receipt

ONE = Decimal("1")


def get_settings(entity):
    try:
        return entity.expense_settings
    except ObjectDoesNotExist:
        raise ValidationError(
            "Expense accounts aren't set up for this entity. Run `python manage.py seed_expenses` "
            "or add Expense settings in the admin."
        )


def _check_money_account(entity, account, what):
    if account is None or account.entity_id != entity.pk or account.type != Account.ASSET or not account.is_postable or not account.is_active:
        raise ValidationError(f"Choose an active bank, cash or card account of this entity for {what}.")


@transaction.atomic
def submit_expense(*, entity, user, date, description, account, amount, currency, paid_by, tax_rate=None, receipt=None):
    ledger.require_submit(user, entity)
    get_settings(entity)
    billing.get_settings(entity)
    if account.entity_id != entity.pk or account.type != Account.EXPENSE or not account.is_active or not account.is_postable:
        raise ValidationError("Choose an active expense category of this entity.")
    if tax_rate is not None and tax_rate.entity_id != entity.pk:
        raise ValidationError("That tax rate belongs to a different entity.")
    if amount is None or amount <= 0:
        raise ValidationError("The amount must be above zero.")
    if paid_by not in (Expense.CLAIMANT, Expense.COMPANY):
        raise ValidationError("Say who paid.")
    if receipt:
        validate_receipt(receipt)
    expense = Expense.objects.create(
        entity=entity, submitted_by=user, date=date, description=description, account=account, amount=amount,
        currency=currency, tax_rate=tax_rate, paid_by=paid_by, receipt=receipt or "",
    )
    ledger.log(entity, user, "submit_expense", expense, f"{description} {amount} {currency.pk}")
    return expense


@transaction.atomic
def approve_expense(expense, user, paid_from=None):
    membership = ledger.require_post(user, expense.entity)
    expense = Expense.objects.select_for_update().get(pk=expense.pk)
    if expense.status != Expense.SUBMITTED:
        raise ValidationError("Only submitted expenses can be approved.")
    if expense.submitted_by_id == user.pk and membership.role != Membership.ADMIN:
        raise PermissionDenied("You can't approve your own expense. Ask another finance user or an admin.")
    entity = expense.entity
    vat_cfg = billing.get_settings(entity)
    cfg = get_settings(entity)
    cur = expense.currency
    rate = ledger.resolve_rate(entity, cur, expense.date)

    def row(account, debit=None, credit=None, description=""):
        return {"account": account, "currency": cur, "fx_rate": rate, "debit": debit, "credit": credit, "description": description}

    if expense.paid_by == Expense.COMPANY:
        _check_money_account(entity, paid_from, "the payment")
        credit_account, credit_note = paid_from, "Paid by company"
    else:
        credit_account, credit_note = cfg.reimbursable_payable, f"Owed to {expense.submitted_by.username}"
    lines = [row(expense.account, debit=expense.net, description=expense.description)]
    if expense.tax:
        lines.append(row(vat_cfg.vat_input, debit=expense.tax, description="Input VAT"))
    lines.append(row(credit_account, credit=expense.amount, description=credit_note))
    billing._fx_balance(entity, vat_cfg, lines)

    journal = ledger.create_draft(
        entity=entity, user=user, date=expense.date, memo=f"Expense {expense}: {expense.description}",
        lines=lines, reference=str(expense), source="expense",
    )
    ledger.post_journal(journal, user)
    expense.journal_id = journal.pk
    expense.fx_rate = rate
    expense.paid_from = paid_from if expense.paid_by == Expense.COMPANY else None
    expense.status = Expense.APPROVED
    expense.decided_by, expense.decided_at = user, timezone.now()
    expense.save()
    ledger.log(entity, user, "approve_expense", expense, f"{expense.amount} {cur.pk}")
    return expense


@transaction.atomic
def reject_expense(expense, user, reason):
    ledger.require_post(user, expense.entity)
    expense = Expense.objects.select_for_update().get(pk=expense.pk)
    if expense.status != Expense.SUBMITTED:
        raise ValidationError("Only submitted expenses can be rejected.")
    if not reason or not reason.strip():
        raise ValidationError("Give a reason so the claimant knows what to fix.")
    expense.status, expense.reject_reason = Expense.REJECTED, reason.strip()[:255]
    expense.decided_by, expense.decided_at = user, timezone.now()
    expense.save()
    ledger.log(expense.entity, user, "reject_expense", expense, expense.reject_reason)
    return expense


@transaction.atomic
def reimburse_expense(expense, user, bank_account, date):
    """Pay the claimant back. Paid in the entity's base currency at the rate fixed on approval."""
    ledger.require_post(user, expense.entity)
    expense = Expense.objects.select_for_update().get(pk=expense.pk)
    if expense.status != Expense.APPROVED or expense.paid_by != Expense.CLAIMANT:
        raise ValidationError("Only approved out-of-pocket claims can be reimbursed.")
    entity = expense.entity
    cfg = get_settings(entity)
    _check_money_account(entity, bank_account, "the reimbursement")
    base_amount = money(expense.amount * expense.fx_rate)
    lines = [
        {"account": cfg.reimbursable_payable, "currency": expense.currency, "fx_rate": expense.fx_rate,
         "debit": expense.amount, "description": f"Reimburse {expense.submitted_by.username}"},
        {"account": bank_account, "currency": entity.base_currency, "fx_rate": ONE, "credit": base_amount,
         "description": f"Reimbursed {expense}"},
    ]
    journal = ledger.create_draft(
        entity=entity, user=user, date=date, memo=f"Reimbursement {expense}: {expense.description}",
        lines=lines, reference=str(expense), source="reimbursement",
    )
    ledger.post_journal(journal, user)
    expense.reimbursement_journal_id = journal.pk
    expense.status, expense.reimbursed_at = Expense.REIMBURSED, timezone.now()
    expense.save()
    ledger.log(entity, user, "reimburse_expense", expense, f"{base_amount} {entity.base_currency_id}")
    return expense


@transaction.atomic
def void_reimbursement(expense, user):
    ledger.require_post(user, expense.entity)
    expense = Expense.objects.select_for_update().get(pk=expense.pk)
    if expense.status != Expense.REIMBURSED:
        raise ValidationError("This expense hasn't been reimbursed.")
    ledger.reverse_journal(expense.reimbursement_journal, user, system=True)
    expense.reimbursement_journal = None
    expense.status, expense.reimbursed_at = Expense.APPROVED, None
    expense.save()
    ledger.log(expense.entity, user, "void_reimbursement", expense, "reversed")
    return expense


@transaction.atomic
def void_expense(expense, user):
    ledger.require_post(user, expense.entity)
    expense = Expense.objects.select_for_update().get(pk=expense.pk)
    if expense.status == Expense.REIMBURSED:
        raise ValidationError("Void the reimbursement first.")
    if expense.status != Expense.APPROVED:
        raise ValidationError("Only approved expenses can be voided.")
    ledger.reverse_journal(expense.journal, user, system=True)
    expense.status = Expense.VOID
    expense.save()
    ledger.log(expense.entity, user, "void_expense", expense, "reversed")
    return expense


@transaction.atomic
def withdraw_expense(expense, user):
    """The claimant takes back a claim that hasn't been decided yet."""
    expense = Expense.objects.select_for_update().get(pk=expense.pk)
    membership = ledger.membership_for(user, expense.entity)
    if not membership or not (expense.submitted_by_id == user.pk or membership.can_post):
        raise PermissionDenied("You can't withdraw this expense.")
    if expense.status != Expense.SUBMITTED:
        raise ValidationError("Only expenses that haven't been decided can be withdrawn.")
    ledger.log(expense.entity, user, "withdraw_expense", expense, expense.description)
    if expense.receipt:
        expense.receipt.delete(save=False)
    expense.delete()
