"""Link expenses to each entity's chart of accounts (the 'owed to staff' liability).

Safe to run repeatedly. Uses account 2200 (Accrued expenses) from the starter chart as a placeholder:
the accountant may prefer a dedicated 'Staff reimbursements payable' account.
"""

from django.core.management.base import BaseCommand

from core.models import Entity
from expenses.models import ExpenseSettings
from ledger.models import Account


class Command(BaseCommand):
    help = "Create expense settings for entities using the starter chart."

    def handle(self, *args, **opts):
        done = 0
        for entity in Entity.objects.all():
            acct = Account.objects.filter(entity=entity, code="2200").first()
            if acct is None:
                self.stdout.write(f"Skipped {entity.name}: account 2200 not found. Add Expense settings in the admin.")
                continue
            ExpenseSettings.objects.get_or_create(entity=entity, defaults={"reimbursable_payable": acct})
            done += 1
        self.stdout.write(self.style.SUCCESS(f"Expenses set up for {done} entity(ies)."))
