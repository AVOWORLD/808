from django.urls import path

from . import views

urlpatterns = [
    path("expenses/", views.expense_list, name="expense_list"),
    path("expenses/new/", views.expense_new, name="expense_new"),
    path("expenses/<int:pk>/", views.expense_detail, name="expense_detail"),
    path("expenses/<int:pk>/receipt/", views.expense_receipt, name="expense_receipt"),
    path("expenses/<int:pk>/<str:action>/", views.expense_action, name="expense_action"),
]
