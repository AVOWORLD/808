import shutil
import tempfile
from datetime import date
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import TestCase, override_settings
from django.urls import reverse

from billing.models import TaxRate
from core.models import Currency, Entity, ExchangeRate, Membership
from ledger import services as ledger
from ledger.models import Account

from . import services
from .models import Expense

User = get_user_model()
D = Decimal
PDF = b"%PDF-1.4\n%fake but correctly signed\n"
PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 20


@override_settings(MEDIA_ROOT=tempfile.mkdtemp(prefix="books-test-media-"))
class Base(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_malawi", verbosity=0)
        cls.entity = Entity.objects.get(name="808 Computing Malawi")
        cls.mwk, cls.usd = Currency.objects.get(code="MWK"), Currency.objects.get(code="USD")
        mk = lambda name, role: (lambda u: (Membership.objects.create(user=u, entity=cls.entity, role=role), u)[1])(User.objects.create_user(name, password="pw"))
        cls.admin, cls.fin, cls.sub, cls.sub2, cls.view = (
            mk("adm", "admin"), mk("fin", "finance"), mk("sub", "submitter"), mk("sub2", "submitter"), mk("view", "viewer"))
        cls.acct = {a.code: a for a in Account.objects.filter(entity=cls.entity)}
        cls.vat = TaxRate.objects.get(entity=cls.entity, name__startswith="VAT standard")

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        from django.conf import settings
        shutil.rmtree(settings.MEDIA_ROOT, ignore_errors=True)

    def submit(self, user=None, amount="1165", paid_by="claimant", tax=True, currency=None, receipt=None, account="5030"):
        return services.submit_expense(
            entity=self.entity, user=user or self.sub, date=date(2026, 11, 3), description="Taxi to site visit",
            account=self.acct[account], amount=D(amount), currency=currency or self.mwk, paid_by=paid_by,
            tax_rate=self.vat if tax else None, receipt=receipt,
        )

    def balances(self):
        rows, dr, cr = ledger.trial_balance(self.entity)
        return {r["account"].code: r["debit"] - r["credit"] for r in rows}, dr, cr


class Rules(Base):
    def test_tax_is_split_out_of_the_receipt_total(self):
        e = self.submit()
        self.assertEqual((e.net, e.tax, e.amount), (D("1000.00"), D("165.00"), D("1165.00")))
        self.assertEqual(self.submit(tax=False).tax, D("0.00"))

    def test_approval_posts_expense_vat_and_amount_owed(self):
        e = services.approve_expense(self.submit(), self.fin)
        self.assertEqual(e.status, "approved")
        bal, dr, cr = self.balances()
        self.assertEqual((bal["5030"], bal["1300"], bal["2200"]), (D("1000.00"), D("165.00"), D("-1165.00")))
        self.assertEqual(dr, cr)
        self.assertEqual(e.journal.source, "expense")

    def test_reimbursement_clears_what_is_owed(self):
        e = services.approve_expense(self.submit(), self.fin)
        services.reimburse_expense(e, self.fin, self.acct["1010"], date(2026, 11, 10))
        bal, dr, cr = self.balances()
        self.assertEqual((bal["2200"], bal["1010"]), (D("0.00"), D("-1165.00")))
        self.assertEqual(dr, cr)
        self.assertEqual(Expense.objects.get(pk=e.pk).status, "reimbursed")
        with self.assertRaises(ValidationError):
            services.reimburse_expense(e, self.fin, self.acct["1010"], date(2026, 11, 11))

    def test_company_paid_goes_straight_to_the_bank_account(self):
        e = self.submit(paid_by="company")
        with self.assertRaises(ValidationError):
            services.approve_expense(e, self.fin)  # needs the account it was paid from
        services.approve_expense(e, self.fin, paid_from=self.acct["1010"])
        bal, dr, cr = self.balances()
        self.assertEqual((bal["1010"], bal.get("2200", D("0"))), (D("-1165.00"), D("0")))
        self.assertEqual(dr, cr)
        with self.assertRaises(ValidationError):
            services.reimburse_expense(Expense.objects.get(pk=e.pk), self.fin, self.acct["1010"], date(2026, 11, 10))

    def test_self_approval_blocked_for_finance_allowed_for_admin(self):
        own = self.submit(user=self.fin)
        with self.assertRaises(PermissionDenied):
            services.approve_expense(own, self.fin)
        services.approve_expense(own, self.admin)
        mine = self.submit(user=self.admin)
        services.approve_expense(mine, self.admin)

    def test_submitters_cannot_approve_and_viewers_cannot_submit(self):
        with self.assertRaises(PermissionDenied):
            services.approve_expense(self.submit(), self.sub)
        with self.assertRaises(PermissionDenied):
            self.submit(user=self.view)

    def test_reject_needs_a_reason_and_posts_nothing(self):
        e = self.submit()
        with self.assertRaises(ValidationError):
            services.reject_expense(e, self.fin, "  ")
        services.reject_expense(e, self.fin, "Wrong category")
        self.assertEqual(self.balances()[0], {})
        with self.assertRaises(ValidationError):
            services.approve_expense(e, self.fin)

    def test_withdraw_only_while_undecided_by_owner_or_finance(self):
        e = self.submit()
        with self.assertRaises(PermissionDenied):
            services.withdraw_expense(e, self.sub2)
        services.withdraw_expense(e, self.sub)
        self.assertFalse(Expense.objects.filter(pk=e.pk).exists())
        done = services.approve_expense(self.submit(), self.fin)
        with self.assertRaises(ValidationError):
            services.withdraw_expense(done, self.sub)

    def test_void_order_and_owned_journal_protection(self):
        e = services.approve_expense(self.submit(), self.fin)
        with self.assertRaises(ValidationError):
            ledger.reverse_journal(e.journal, self.fin)  # must go through the expense
        services.reimburse_expense(e, self.fin, self.acct["1010"], date(2026, 11, 10))
        with self.assertRaises(ValidationError):
            ledger.reverse_journal(Expense.objects.get(pk=e.pk).reimbursement_journal, self.fin)
        with self.assertRaises(ValidationError):
            services.void_expense(Expense.objects.get(pk=e.pk), self.fin)
        services.void_reimbursement(Expense.objects.get(pk=e.pk), self.fin)
        services.void_expense(Expense.objects.get(pk=e.pk), self.fin)
        bal, dr, cr = self.balances()
        self.assertTrue(all(v == 0 for v in bal.values()), bal)

    def test_category_must_be_an_expense_account_of_this_entity(self):
        with self.assertRaises(ValidationError):
            self.submit(account="4010")
        with self.assertRaises(ValidationError):
            self.submit(amount="0")

    def test_foreign_currency_expense_balances_at_the_approval_rate(self):
        ExchangeRate.objects.create(currency=self.usd, to_currency=self.mwk, date=date(2026, 11, 1), rate=D("1750.537"))
        e = services.approve_expense(self.submit(amount="33.33", currency=self.usd), self.fin)
        self.assertEqual(e.fx_rate, D("1750.537"))
        services.reimburse_expense(e, self.fin, self.acct["1010"], date(2026, 11, 10))
        bal, dr, cr = self.balances()
        self.assertEqual(dr, cr)
        self.assertEqual(bal["2200"], D("0.00"))


class Receipts(Base):
    def test_valid_receipt_is_stored_privately(self):
        e = self.submit(receipt=SimpleUploadedFile("slip.pdf", PDF))
        self.assertTrue(e.receipt.name.startswith(f"receipts/{self.entity.pk}/"))
        self.assertNotIn("slip", e.receipt.name)

    def test_bad_receipts_are_refused(self):
        for name, body in (("virus.exe", b"MZ"), ("fake.pdf", b"not a pdf"), ("big.pdf", PDF + b"0" * (5 * 1024 * 1024)), ("shell.png", PDF)):
            with self.assertRaises(ValidationError, msg=name):
                self.submit(receipt=SimpleUploadedFile(name, body))
        self.assertFalse(Expense.objects.exists())

    def test_withdrawing_deletes_the_file(self):
        e = self.submit(receipt=SimpleUploadedFile("a.png", PNG))
        path = e.receipt.path
        import os
        self.assertTrue(os.path.exists(path))
        services.withdraw_expense(e, self.sub)
        self.assertFalse(os.path.exists(path))

    def test_download_is_access_checked(self):
        e = self.submit(user=self.sub, receipt=SimpleUploadedFile("a.pdf", PDF))
        url = reverse("expense_receipt", args=[e.pk])
        self.assertEqual(self.client.get(url).status_code, 302)  # anonymous: login
        for user, expected in (("sub", 200), ("fin", 200), ("sub2", 404)):
            self.client.logout()
            self.client.login(username=user, password="pw")
            resp = self.client.get(url)
            self.assertEqual(resp.status_code, expected, user)
        self.client.login(username="sub", password="pw")
        resp = self.client.get(url)
        self.assertEqual(resp["Content-Type"], "application/pdf")
        self.assertEqual(resp["X-Content-Type-Options"], "nosniff")
        self.assertEqual(b"".join(resp.streaming_content), PDF)
        other = Entity.objects.create(name="808 Kenya", country="KE", base_currency=Currency.objects.get(code="KES"))
        ken = User.objects.create_user("ken", password="pw")
        Membership.objects.create(user=ken, entity=other, role="admin")
        self.client.logout()
        self.client.login(username="ken", password="pw")
        self.assertEqual(self.client.get(url).status_code, 404)


class Screens(Base):
    def test_submit_approve_reimburse_through_the_screens(self):
        self.client.login(username="sub", password="pw")
        self.assertEqual(self.client.get(reverse("expense_new")).status_code, 200)
        resp = self.client.post(reverse("expense_new"), {
            "date": "2026-11-03", "description": "Fuel", "account": self.acct["5030"].pk, "amount": "1165.00", "currency": "MWK",
            "tax_rate": self.vat.pk, "paid_by": "claimant", "receipt": SimpleUploadedFile("fuel.pdf", PDF)})
        self.assertEqual(resp.status_code, 302)
        e = Expense.objects.get(description="Fuel")
        self.assertTrue(e.receipt)
        self.client.logout()
        self.client.login(username="fin", password="pw")
        self.assertContains(self.client.get(reverse("expense_list")), "Fuel")
        self.assertContains(self.client.get(reverse("expense_detail", args=[e.pk])), "Approve and post")
        self.client.post(reverse("expense_action", args=[e.pk, "approve"]), {})
        self.assertEqual(Expense.objects.get(pk=e.pk).status, "approved")
        self.assertContains(self.client.get(reverse("expense_detail", args=[e.pk])), "Record reimbursement")
        self.client.post(reverse("expense_action", args=[e.pk, "reimburse"]), {"date": "2026-11-10", "bank_account": self.acct["1010"].pk})
        self.assertEqual(Expense.objects.get(pk=e.pk).status, "reimbursed")

    def test_submitters_only_see_their_own_claims(self):
        mine, theirs = self.submit(user=self.sub), self.submit(user=self.sub2)
        self.client.login(username="sub", password="pw")
        self.assertEqual(self.client.get(reverse("expense_detail", args=[mine.pk])).status_code, 200)
        self.assertEqual(self.client.get(reverse("expense_detail", args=[theirs.pk])).status_code, 404)
        self.assertEqual(len(self.client.get(reverse("expense_list")).context["expenses"]), 1)

    def test_bad_upload_shows_an_error_and_saves_nothing(self):
        self.client.login(username="sub", password="pw")
        resp = self.client.post(reverse("expense_new"), {
            "date": "2026-11-03", "description": "Fuel", "account": self.acct["5030"].pk, "amount": "10", "currency": "MWK",
            "paid_by": "claimant", "receipt": SimpleUploadedFile("evil.exe", b"MZ")})
        self.assertContains(resp, "PDF, JPG or PNG")
        self.assertFalse(Expense.objects.exists())
