import mimetypes

from django.contrib import messages
from django.core.exceptions import PermissionDenied, ValidationError
from django.db.models import Sum
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from core.models import Membership
from ledger.models import ZERO
from ledger.views import entity_required

from . import services
from .forms import ApproveForm, ExpenseForm, RejectForm, ReimburseForm
from .models import Expense


def _msgs(exc):
    return " ".join(exc.messages) if isinstance(exc, ValidationError) else (str(exc) or "Not allowed.")


def _visible(request):
    """Submitters see only their own claims; finance, admin and viewers see the entity's."""
    qs = Expense.objects.filter(entity=request.membership.entity).select_related("submitted_by", "account", "currency")
    if request.membership.role == Membership.SUBMITTER:
        qs = qs.filter(submitted_by=request.user)
    return qs


@entity_required
def expense_list(request):
    qs = _visible(request)
    status = request.GET.get("status")
    pending = qs.filter(status=Expense.SUBMITTED).count()
    owed = qs.filter(status=Expense.APPROVED, paid_by=Expense.CLAIMANT).aggregate(s=Sum("amount"))["s"] or ZERO
    if status == "awaiting":
        qs = qs.filter(status=Expense.APPROVED, paid_by=Expense.CLAIMANT)
    elif status in dict(Expense.STATUSES):
        qs = qs.filter(status=status)
    return render(request, "expenses/expense_list.html", {"expenses": qs[:200], "status": status, "pending": pending, "owed": owed})


@entity_required
def expense_new(request):
    membership = request.membership
    if not membership.can_submit:
        raise PermissionDenied
    entity = membership.entity
    form = ExpenseForm(request.POST or None, request.FILES or None, entity=entity)
    if request.method == "POST" and form.is_valid():
        d = form.cleaned_data
        try:
            expense = services.submit_expense(
                entity=entity, user=request.user, date=d["date"], description=d["description"], account=d["account"],
                amount=d["amount"], currency=d["currency"], paid_by=d["paid_by"], tax_rate=d["tax_rate"], receipt=d["receipt"],
            )
        except (ValidationError, PermissionDenied) as exc:
            form.add_error(None, _msgs(exc))
        else:
            messages.success(request, f"{expense} submitted for approval.")
            return redirect("expense_detail", pk=expense.pk)
    return render(request, "expenses/expense_form.html", {"form": form})


@entity_required
def expense_detail(request, pk):
    membership = request.membership
    expense = get_object_or_404(_visible(request).select_related("journal", "reimbursement_journal", "decided_by", "tax_rate", "paid_from"), pk=pk)
    ctx = {"expense": expense}
    if membership.can_post:
        entity = membership.entity
        if expense.status == Expense.SUBMITTED:
            ctx["approve_form"] = ApproveForm(entity=entity, company_paid=expense.paid_by == Expense.COMPANY)
            ctx["reject_form"] = RejectForm()
        if expense.status == Expense.APPROVED and expense.paid_by == Expense.CLAIMANT:
            ctx["reimburse_form"] = ReimburseForm(entity=entity)
    ctx["can_withdraw"] = expense.status == Expense.SUBMITTED and (expense.submitted_by_id == request.user.pk or membership.can_post)
    return render(request, "expenses/expense_detail.html", ctx)


@entity_required
def expense_receipt(request, pk):
    expense = get_object_or_404(_visible(request), pk=pk)
    if not expense.receipt:
        raise Http404("No receipt")
    try:
        handle = expense.receipt.open("rb")
    except FileNotFoundError:
        raise Http404("Receipt file is missing")
    kind = mimetypes.guess_type(expense.receipt.name)[0] or "application/octet-stream"
    response = FileResponse(handle, content_type=kind)
    response["Content-Disposition"] = f'inline; filename="{expense}{expense.receipt.name[expense.receipt.name.rfind("."):]}"'
    response["X-Content-Type-Options"] = "nosniff"
    response["Cache-Control"] = "private, no-store"
    return response


@entity_required
@require_POST
def expense_action(request, pk, action):
    entity = request.membership.entity
    expense = get_object_or_404(_visible(request), pk=pk)
    try:
        if action == "approve":
            form = ApproveForm(request.POST, entity=entity, company_paid=expense.paid_by == Expense.COMPANY)
            if not form.is_valid():
                raise ValidationError([e for errs in form.errors.values() for e in errs])
            services.approve_expense(expense, request.user, paid_from=form.cleaned_data.get("paid_from"))
            messages.success(request, f"{expense} approved and posted to the ledger.")
        elif action == "reject":
            form = RejectForm(request.POST)
            if not form.is_valid():
                raise ValidationError("Give a reason so the claimant knows what to fix.")
            services.reject_expense(expense, request.user, form.cleaned_data["reason"])
            messages.success(request, f"{expense} rejected.")
        elif action == "reimburse":
            form = ReimburseForm(request.POST, entity=entity)
            if not form.is_valid():
                raise ValidationError([e for errs in form.errors.values() for e in errs])
            services.reimburse_expense(expense, request.user, form.cleaned_data["bank_account"], form.cleaned_data["date"])
            messages.success(request, f"{expense} reimbursed.")
        elif action == "void":
            services.void_expense(expense, request.user)
            messages.success(request, f"{expense} voided and its journal reversed.")
        elif action == "void-reimbursement":
            services.void_reimbursement(expense, request.user)
            messages.success(request, "Reimbursement voided. The claim is awaiting reimbursement again.")
        elif action == "withdraw":
            services.withdraw_expense(expense, request.user)
            messages.success(request, "Expense withdrawn.")
            return redirect("expense_list")
        else:
            raise ValidationError("Unknown action.")
    except (ValidationError, PermissionDenied) as exc:
        messages.error(request, _msgs(exc))
    return redirect("expense_detail", pk=pk)
