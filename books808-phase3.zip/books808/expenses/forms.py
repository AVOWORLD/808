from decimal import Decimal

from django import forms
from django.utils import timezone

from billing.models import TaxRate
from core.models import Currency
from ledger.models import Account

from .models import Expense
from .validators import validate_receipt


class ExpenseForm(forms.Form):
    date = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}), initial=timezone.localdate)
    description = forms.CharField(max_length=255, help_text="What it was and who it was paid to.")
    account = forms.ModelChoiceField(queryset=Account.objects.none(), label="Category")
    amount = forms.DecimalField(max_digits=18, decimal_places=2, min_value=Decimal("0.01"), help_text="The full amount on the receipt, tax included.")
    currency = forms.ModelChoiceField(queryset=Currency.objects.all())
    tax_rate = forms.ModelChoiceField(queryset=TaxRate.objects.none(), required=False, empty_label="No tax / not claimable")
    paid_by = forms.ChoiceField(choices=Expense.PAID_BY, initial=Expense.CLAIMANT, widget=forms.RadioSelect)
    receipt = forms.FileField(required=False, help_text="PDF, JPG or PNG, up to 5 MB.")

    def __init__(self, *args, entity, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["account"].queryset = Account.objects.filter(
            entity=entity, type=Account.EXPENSE, is_active=True, is_postable=True
        )
        self.fields["tax_rate"].queryset = TaxRate.objects.filter(entity=entity, is_active=True)
        self.fields["currency"].initial = entity.base_currency_id

    def clean_receipt(self):
        f = self.cleaned_data.get("receipt")
        if f:
            validate_receipt(f)
        return f


class MoneyAccountMixin:
    def _money_accounts(self, entity):
        return Account.objects.filter(entity=entity, type=Account.ASSET, is_active=True, is_postable=True)


class ApproveForm(forms.Form, MoneyAccountMixin):
    paid_from = forms.ModelChoiceField(queryset=Account.objects.none(), required=False, label="Paid from")

    def __init__(self, *args, entity, company_paid=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.company_paid = company_paid
        self.fields["paid_from"].queryset = self._money_accounts(entity)
        self.fields["paid_from"].required = company_paid

    def clean(self):
        data = super().clean()
        if self.company_paid and not data.get("paid_from"):
            raise forms.ValidationError("Choose the company account or card this was paid from.")
        return data


class RejectForm(forms.Form):
    reason = forms.CharField(max_length=255)


class ReimburseForm(forms.Form, MoneyAccountMixin):
    date = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}), initial=timezone.localdate)
    bank_account = forms.ModelChoiceField(queryset=Account.objects.none(), label="Paid from")

    def __init__(self, *args, entity, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["bank_account"].queryset = self._money_accounts(entity)
