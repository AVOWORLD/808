import os

from django.core.exceptions import ValidationError

ALLOWED = {".pdf", ".jpg", ".jpeg", ".png"}
MAX_BYTES = 5 * 1024 * 1024
MAGIC = {
    ".pdf": (b"%PDF",),
    ".png": (b"\x89PNG\r\n\x1a\n",),
    ".jpg": (b"\xff\xd8\xff",),
    ".jpeg": (b"\xff\xd8\xff",),
}


def validate_receipt(upload):
    """Receipts must be a PDF, JPG or PNG up to 5 MB, and the content must match the extension."""
    ext = os.path.splitext(upload.name)[1].lower()
    if ext not in ALLOWED:
        raise ValidationError("Receipts must be a PDF, JPG or PNG file.")
    if upload.size > MAX_BYTES:
        raise ValidationError("Receipts can be at most 5 MB.")
    head = upload.read(8)
    upload.seek(0)
    if not any(head.startswith(sig) for sig in MAGIC[ext]):
        raise ValidationError("That file's content doesn't match its type. Upload the original PDF, JPG or PNG.")
