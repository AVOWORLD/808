from datetime import date
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse

from core.models import Currency, Entity, ExchangeRate, Membership

from . import services
from .models import Account, AuditLog, Journal

User = get_user_model()
D = Decimal


class LedgerBase(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_malawi", verbosity=0)
        cls.entity = Entity.objects.get(name="808 Computing Malawi")
        cls.mwk = Currency.objects.get(code="MWK")
        cls.usd = Currency.objects.get(code="USD")
        cls.finance = User.objects.create_user("fin", password="pw")
        cls.submitter = User.objects.create_user("sub", password="pw")
        cls.viewer = User.objects.create_user("view", password="pw")
        Membership.objects.create(user=cls.finance, entity=cls.entity, role=Membership.FINANCE)
        Membership.objects.create(user=cls.submitter, entity=cls.entity, role=Membership.SUBMITTER)
        Membership.objects.create(user=cls.viewer, entity=cls.entity, role=Membership.VIEWER)
        cls.bank = Account.objects.get(entity=cls.entity, code="1010")
        cls.capital = Account.objects.get(entity=cls.entity, code="3010")
        cls.fees = Account.objects.get(entity=cls.entity, code="4010")

    def draft(self, amount="1000", user=None, memo="Capital in", currency=None, **extra):
        currency = currency or self.mwk
        return services.create_draft(
            entity=self.entity,
            user=user or self.finance,
            date=date(2026, 11, 8),
            memo=memo,
            lines=[
                {"account": self.bank, "currency": currency, "debit": amount},
                {"account": self.capital, "currency": currency, "credit": amount},
            ],
            **extra,
        )


class PostingRules(LedgerBase):
    def test_balanced_journal_posts_and_gets_a_number(self):
        j = services.post_journal(self.draft(), self.finance)
        self.assertEqual(j.status, Journal.POSTED)
        self.assertEqual(j.number, 1)
        second = services.post_journal(self.draft(memo="More"), self.finance)
        self.assertEqual(second.number, 2)

    def test_unbalanced_journal_is_refused(self):
        j = services.create_draft(
            entity=self.entity, user=self.finance, date=date(2026, 11, 8), memo="Bad",
            lines=[
                {"account": self.bank, "currency": self.mwk, "debit": "100"},
                {"account": self.capital, "currency": self.mwk, "credit": "90"},
            ],
        )
        with self.assertRaises(ValidationError):
            services.post_journal(j, self.finance)
        j.refresh_from_db()
        self.assertEqual(j.status, Journal.DRAFT)

    def test_header_account_cannot_be_posted_to(self):
        header = Account.objects.get(entity=self.entity, code="1000")
        j = services.create_draft(
            entity=self.entity, user=self.finance, date=date(2026, 11, 8), memo="Header",
            lines=[
                {"account": header, "currency": self.mwk, "debit": "5"},
                {"account": self.capital, "currency": self.mwk, "credit": "5"},
            ],
        )
        with self.assertRaises(ValidationError):
            services.post_journal(j, self.finance)

    def test_posted_journal_is_immutable(self):
        j = services.post_journal(self.draft(), self.finance)
        j.memo = "Edited"
        with self.assertRaises(ValidationError):
            j.save()
        with self.assertRaises(ValidationError):
            j.delete()
        line = j.lines.first()
        line.debit = D("1")
        with self.assertRaises(ValidationError):
            line.save()
        with self.assertRaises(ValidationError):
            line.delete()

    def test_reversal_nets_to_zero_and_cannot_repeat(self):
        j = services.post_journal(self.draft(), self.finance)
        rev = services.reverse_journal(j, self.finance, date=date(2026, 11, 9))
        self.assertEqual(rev.reversal_of_id, j.pk)
        rows, dr, cr = services.trial_balance(self.entity)
        self.assertEqual(dr, D("0.00"))
        self.assertEqual(cr, D("0.00"))
        with self.assertRaises(ValidationError):
            services.reverse_journal(j, self.finance)

    def test_roles(self):
        with self.assertRaises(PermissionDenied):
            self.draft(user=self.viewer)
        d = self.draft(user=self.submitter)
        with self.assertRaises(PermissionDenied):
            services.post_journal(d, self.submitter)
        services.post_journal(d, self.finance)

    def test_foreign_currency_uses_stored_rate(self):
        with self.assertRaises(ValidationError):
            self.draft(amount="10", currency=self.usd)
        ExchangeRate.objects.create(currency=self.usd, to_currency=self.mwk, date=date(2026, 11, 1), rate=D("1750.5"))
        j = services.post_journal(self.draft(amount="10", currency=self.usd), self.finance)
        self.assertEqual(j.totals, (D("17505.00"), D("17505.00")))

    def test_audit_trail_records_actions(self):
        j = services.post_journal(self.draft(), self.finance)
        actions = list(AuditLog.objects.filter(object_id=j.pk).values_list("action", flat=True))
        self.assertIn("create_draft", actions)
        self.assertIn("post", actions)
        entry = AuditLog.objects.first()
        entry.detail = "tampered"
        with self.assertRaises(ValidationError):
            entry.save()

    def test_trial_balance_balances_and_respects_date(self):
        services.post_journal(self.draft("500"), self.finance)
        rows, dr, cr = services.trial_balance(self.entity)
        self.assertEqual((dr, cr), (D("500.00"), D("500.00")))
        rows, dr, cr = services.trial_balance(self.entity, as_of=date(2026, 1, 1))
        self.assertEqual(rows, [])

    def test_other_entity_accounts_are_rejected(self):
        other = Entity.objects.create(name="808 Computing Kenya", country="KE", base_currency=Currency.objects.get(code="KES"))
        foreign = Account.objects.create(entity=other, code="1010", name="Bank", type="asset")
        Membership.objects.create(user=self.finance, entity=other, role=Membership.FINANCE)
        with self.assertRaises(ValidationError):
            services.create_draft(
                entity=self.entity, user=self.finance, date=date(2026, 11, 8), memo="Cross",
                lines=[
                    {"account": foreign, "currency": self.mwk, "debit": "1"},
                    {"account": self.capital, "currency": self.mwk, "credit": "1"},
                ],
            )


class Screens(LedgerBase):
    def test_login_required(self):
        self.assertEqual(self.client.get(reverse("dashboard")).status_code, 302)

    def test_pages_render_for_finance(self):
        self.client.login(username="fin", password="pw")
        for name in ("dashboard", "accounts", "journals", "journal_new", "trial_balance"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)

    def test_create_and_post_through_the_form(self):
        self.client.login(username="fin", password="pw")
        data = {
            "date": "2026-11-08", "memo": "Pilot fee", "reference": "INV-1",
            "form-TOTAL_FORMS": "4", "form-INITIAL_FORMS": "0", "form-MIN_NUM_FORMS": "0", "form-MAX_NUM_FORMS": "1000",
            "form-0-account": self.bank.pk, "form-0-currency": "MWK", "form-0-debit": "2500",
            "form-1-account": self.fees.pk, "form-1-currency": "MWK", "form-1-credit": "2500",
            "post": "1",
        }
        resp = self.client.post(reverse("journal_new"), data)
        self.assertEqual(resp.status_code, 302)
        j = Journal.objects.get(memo="Pilot fee")
        self.assertEqual(j.status, Journal.POSTED)
        page = self.client.get(reverse("trial_balance"))
        self.assertContains(page, "Debits equal credits")
        self.assertContains(self.client.get(reverse("journal_detail", args=[j.pk])), "Reverse this journal")

    def test_viewer_cannot_open_new_journal_form(self):
        self.client.login(username="view", password="pw")
        self.assertEqual(self.client.get(reverse("journal_new")).status_code, 403)
        self.assertEqual(self.client.get(reverse("dashboard")).status_code, 200)


class Analytics(LedgerBase):
    def _post(self, debit, credit, amount, day):
        j = services.create_draft(
            entity=self.entity, user=self.finance, date=day, memo="x",
            lines=[
                {"account": debit, "currency": self.mwk, "debit": amount},
                {"account": credit, "currency": self.mwk, "credit": amount},
            ],
        )
        services.post_journal(j, self.finance)

    def test_empty_entity_has_no_figures(self):
        from . import analytics
        self.assertIsNone(analytics.income_expense_figure(self.entity))
        self.assertIsNone(analytics.stockpile_value_figure(self.entity))

    def test_income_expense_and_stockpile_series(self):
        from . import analytics
        stock = Account.objects.get(entity=self.entity, code="1210")
        cloud = Account.objects.get(entity=self.entity, code="5010")
        self._post(self.bank, self.fees, "1000", date(2026, 10, 5))
        self._post(cloud, self.bank, "300", date(2026, 10, 20))
        self._post(stock, self.capital, "700", date(2026, 10, 25))
        self._post(stock, self.capital, "200", date(2026, 11, 2))
        months, income, expense = analytics.monthly_income_expense(self.entity)
        self.assertEqual((income, expense), ([D("1000.00")], [D("300.00")]))
        dates, running = analytics.stockpile_value_series(self.entity)
        self.assertEqual(running, [D("700.00"), D("900.00")])
        self.client.login(username="fin", password="pw")
        page = self.client.get(reverse("analytics"))
        self.assertEqual(page.status_code, 200)
        self.assertContains(page, "stockpile-value-data")
        self.assertContains(self.client.get(reverse("dashboard")), "income-expense-data")
