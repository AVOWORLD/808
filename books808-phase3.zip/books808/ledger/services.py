"""Business rules for the ledger. Views call these; nothing else writes journals."""

from decimal import Decimal

from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Max, Sum
from django.utils import timezone

from core.models import Entity, ExchangeRate, Membership

from .models import ZERO, Account, AuditLog, Journal, JournalLine


def membership_for(user, entity):
    return Membership.objects.filter(user=user, entity=entity).first()


def require_submit(user, entity):
    m = membership_for(user, entity)
    if not m or not m.can_submit:
        raise PermissionDenied("You can't create journals in this entity.")
    return m


def require_post(user, entity):
    m = membership_for(user, entity)
    if not m or not m.can_post:
        raise PermissionDenied("Only finance or admin users can post journals.")
    return m


def log(entity, user, action, obj, detail=""):
    AuditLog.objects.create(
        entity=entity, user=user, action=action, object_type=type(obj).__name__, object_id=obj.pk, detail=detail
    )


def resolve_rate(entity, currency, date):
    """Latest stored rate on or before `date` converting `currency` to the entity's base currency."""
    base = entity.base_currency_id
    if currency.pk == base:
        return Decimal("1")
    row = (
        ExchangeRate.objects.filter(currency=currency, to_currency_id=base, date__lte=date).order_by("-date").first()
    )
    if row is None:
        raise ValidationError(f"No exchange rate from {currency.pk} to {base} on or before {date}. Add one first.")
    return row.rate


@transaction.atomic
def create_draft(*, entity, user, date, memo, lines, reference="", source="manual"):
    """lines: list of dicts with account (Account), currency (Currency), debit, credit, description, fx_rate (optional)."""
    require_submit(user, entity)
    journal = Journal.objects.create(
        entity=entity, date=date, memo=memo, reference=reference, source=source, created_by=user
    )
    for row in lines:
        account = row["account"]
        if account.entity_id != entity.pk:
            raise ValidationError(f"Account {account.code} belongs to a different entity.")
        rate = row.get("fx_rate") or resolve_rate(entity, row["currency"], date)
        JournalLine.objects.create(
            journal=journal,
            account=account,
            currency=row["currency"],
            debit=Decimal(row.get("debit") or 0),
            credit=Decimal(row.get("credit") or 0),
            description=row.get("description", ""),
            fx_rate=rate,
        )
    log(entity, user, "create_draft", journal, memo)
    return journal


@transaction.atomic
def post_journal(journal, user):
    require_post(user, journal.entity)
    journal = Journal.objects.select_for_update().get(pk=journal.pk)
    if journal.status == Journal.POSTED:
        raise ValidationError("This journal is already posted.")
    lines = list(journal.lines.select_related("account"))
    if len(lines) < 2:
        raise ValidationError("A journal needs at least two lines.")
    for line in lines:
        acct = line.account
        if acct.entity_id != journal.entity_id:
            raise ValidationError(f"Account {acct.code} belongs to a different entity.")
        if not acct.is_active or not acct.is_postable:
            raise ValidationError(f"Account {acct.code} {acct.name} can't be posted to.")
    debits = sum((l.base_debit for l in lines), ZERO)
    credits = sum((l.base_credit for l in lines), ZERO)
    if debits != credits:
        raise ValidationError(f"Journal does not balance: debits {debits} vs credits {credits} (base currency).")
    if debits == 0:
        raise ValidationError("A journal can't be posted with zero value.")

    entity = Entity.objects.select_for_update().get(pk=journal.entity_id)
    last = Journal.objects.filter(entity=entity).aggregate(m=Max("number"))["m"] or 0
    journal.number = last + 1
    journal.status = Journal.POSTED
    journal.posted_by = user
    journal.posted_at = timezone.now()
    journal._posting = True
    try:
        journal.save()
    finally:
        journal._posting = False
    log(entity, user, "post", journal, f"JE-{journal.number} {debits} {entity.base_currency_id}")
    return journal


@transaction.atomic
def reverse_journal(journal, user, date=None, memo=None, *, system=False):
    """Correct a posted journal by posting its mirror image.

    Journals owned by a business document (invoice, bill, payment, expense) are reversed only by the
    service that voids that document, which passes system=True. Reversing them directly would leave
    the document saying it is still valid."""
    require_post(user, journal.entity)
    if journal.is_system_owned and not system:
        raise ValidationError(
            f"{journal} was created from a {journal.source}. Void the {journal.source} instead of reversing its journal."
        )
    if journal.status != Journal.POSTED:
        raise ValidationError("Only posted journals can be reversed. Edit or delete a draft instead.")
    if hasattr(journal, "reversed_by"):
        raise ValidationError("This journal has already been reversed.")
    rev = Journal.objects.create(
        entity=journal.entity,
        date=date or timezone.localdate(),
        memo=memo or f"Reversal of {journal}: {journal.memo}",
        reference=journal.reference,
        source="reversal",
        created_by=user,
        reversal_of=journal,
    )
    for line in journal.lines.all():
        JournalLine.objects.create(
            journal=rev,
            account=line.account,
            currency=line.currency,
            debit=line.credit,
            credit=line.debit,
            description=line.description,
            fx_rate=line.fx_rate,
        )
    log(journal.entity, user, "reverse", journal, f"reversed by draft {rev.pk}")
    return post_journal(rev, user)


def trial_balance(entity, as_of=None):
    """Posted journals only, in the entity's base currency."""
    lines = JournalLine.objects.filter(journal__entity=entity, journal__status=Journal.POSTED)
    if as_of:
        lines = lines.filter(journal__date__lte=as_of)
    sums = {
        row["account_id"]: row
        for row in lines.values("account_id").annotate(d=Sum("base_debit"), c=Sum("base_credit"))
    }
    rows, total_dr, total_cr = [], ZERO, ZERO
    for account in Account.objects.filter(entity=entity):
        s = sums.get(account.pk)
        if not s:
            continue
        net = (s["d"] or ZERO) - (s["c"] or ZERO)
        dr, cr = (net, ZERO) if net >= 0 else (ZERO, -net)
        rows.append({"account": account, "debit": dr, "credit": cr})
        total_dr += dr
        total_cr += cr
    return rows, total_dr, total_cr
