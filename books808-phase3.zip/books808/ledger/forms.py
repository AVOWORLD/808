from django import forms
from django.forms import formset_factory
from django.utils import timezone

from core.models import Currency

from .models import Account


class JournalForm(forms.Form):
    date = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}), initial=timezone.localdate)
    memo = forms.CharField(max_length=255)
    reference = forms.CharField(max_length=60, required=False)


class LineForm(forms.Form):
    account = forms.ModelChoiceField(queryset=Account.objects.none(), required=False)
    description = forms.CharField(max_length=255, required=False)
    currency = forms.ModelChoiceField(queryset=Currency.objects.all(), required=False)
    debit = forms.DecimalField(min_value=0, max_digits=18, decimal_places=2, required=False)
    credit = forms.DecimalField(min_value=0, max_digits=18, decimal_places=2, required=False)

    def __init__(self, *args, entity=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.entity = entity
        if entity is not None:
            self.fields["account"].queryset = Account.objects.filter(entity=entity, is_active=True, is_postable=True)
            self.fields["currency"].initial = entity.base_currency_id

    def clean(self):
        data = super().clean()
        if not data.get("account"):
            return data
        debit, credit = data.get("debit") or 0, data.get("credit") or 0
        if (debit > 0) == (credit > 0):
            raise forms.ValidationError("Enter either a debit or a credit for each line.")
        if not data.get("currency"):
            data["currency"] = self.entity.base_currency
        return data


LineFormSet = formset_factory(LineForm, extra=4)


class ReverseForm(forms.Form):
    date = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}), initial=timezone.localdate)
