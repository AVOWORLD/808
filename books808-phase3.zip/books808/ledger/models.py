from decimal import ROUND_HALF_UP, Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models

from core.models import Currency, Entity, ExchangeRate

CENT = Decimal("0.01")
ZERO = Decimal("0.00")


def money(value):
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)


class Account(models.Model):
    ASSET, LIABILITY, EQUITY, INCOME, EXPENSE = "asset", "liability", "equity", "income", "expense"
    TYPES = [
        (ASSET, "Asset"),
        (LIABILITY, "Liability"),
        (EQUITY, "Equity"),
        (INCOME, "Income"),
        (EXPENSE, "Expense"),
    ]

    entity = models.ForeignKey(Entity, on_delete=models.CASCADE, related_name="accounts")
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=120)
    type = models.CharField(max_length=10, choices=TYPES)
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.PROTECT, related_name="children")
    is_postable = models.BooleanField(default=True, help_text="Header accounts group others and cannot be posted to.")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]
        constraints = [models.UniqueConstraint(fields=["entity", "code"], name="uniq_account_code_per_entity")]

    def __str__(self):
        return f"{self.code} {self.name}"

    @property
    def normal_side(self):
        return "debit" if self.type in (self.ASSET, self.EXPENSE) else "credit"


# Journals created by these sources belong to a business document (invoice, bill, payment, expense).
# They can only be undone by voiding that document, never by reversing the journal on its own.
OWNED_SOURCES = {"invoice", "bill", "payment", "expense", "reimbursement"}


class Journal(models.Model):
    DRAFT, POSTED = "draft", "posted"
    STATUSES = [(DRAFT, "Draft"), (POSTED, "Posted")]

    entity = models.ForeignKey(Entity, on_delete=models.PROTECT, related_name="journals")
    number = models.PositiveIntegerField(null=True, blank=True, help_text="Assigned when posted.")
    date = models.DateField()
    memo = models.CharField(max_length=255)
    reference = models.CharField(max_length=60, blank=True)
    source = models.CharField(
        max_length=30, default="manual", help_text="manual now; later strata_survey, payment, invoice and so on."
    )
    status = models.CharField(max_length=10, choices=STATUSES, default=DRAFT)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    posted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name="+"
    )
    posted_at = models.DateTimeField(null=True, blank=True)
    reversal_of = models.OneToOneField(
        "self", null=True, blank=True, on_delete=models.PROTECT, related_name="reversed_by"
    )

    class Meta:
        ordering = ["-date", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["entity", "number"],
                condition=models.Q(number__isnull=False),
                name="uniq_journal_number_per_entity",
            )
        ]

    def __str__(self):
        return f"JE-{self.number}" if self.number else f"Draft #{self.pk}"

    # A posted journal is part of the permanent record: it can only be corrected
    # by a reversing journal, never edited or deleted.
    def _stored_status(self):
        if not self.pk:
            return None
        return Journal.objects.filter(pk=self.pk).values_list("status", flat=True).first()

    def save(self, *args, **kwargs):
        if self._stored_status() == self.POSTED and not getattr(self, "_posting", False):
            raise ValidationError("Posted journals cannot be changed. Reverse the journal instead.")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self._stored_status() == self.POSTED:
            raise ValidationError("Posted journals cannot be deleted. Reverse the journal instead.")
        return super().delete(*args, **kwargs)

    @property
    def is_system_owned(self):
        return self.source in OWNED_SOURCES

    @property
    def totals(self):
        lines = list(self.lines.all())
        return (
            sum((l.base_debit for l in lines), ZERO),
            sum((l.base_credit for l in lines), ZERO),
        )


class JournalLine(models.Model):
    journal = models.ForeignKey(Journal, on_delete=models.CASCADE, related_name="lines")
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="lines")
    description = models.CharField(max_length=255, blank=True)
    currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="+")
    debit = models.DecimalField(max_digits=18, decimal_places=2, default=ZERO)
    credit = models.DecimalField(max_digits=18, decimal_places=2, default=ZERO)
    fx_rate = models.DecimalField(
        max_digits=18, decimal_places=6, default=Decimal("1"), help_text="Units of entity base currency per 1 unit of line currency."
    )
    base_debit = models.DecimalField(max_digits=18, decimal_places=2, default=ZERO, editable=False)
    base_credit = models.DecimalField(max_digits=18, decimal_places=2, default=ZERO, editable=False)

    class Meta:
        ordering = ["id"]
        constraints = [
            models.CheckConstraint(condition=models.Q(debit__gte=0) & models.Q(credit__gte=0), name="line_non_negative"),
        ]

    def __str__(self):
        return f"{self.account.code} Dr {self.debit} Cr {self.credit} {self.currency_id}"

    def clean(self):
        if (self.debit > 0) == (self.credit > 0):
            raise ValidationError("A line must have either a debit or a credit amount, not both and not neither.")

    def _journal_status(self):
        return Journal.objects.filter(pk=self.journal_id).values_list("status", flat=True).first()

    def save(self, *args, **kwargs):
        if self._journal_status() == Journal.POSTED:
            raise ValidationError("Lines of a posted journal cannot be changed.")
        self.clean()
        base = self.journal.entity.base_currency_id
        if self.currency_id == base:
            self.fx_rate = Decimal("1")
        self.base_debit = money(self.debit * self.fx_rate)
        self.base_credit = money(self.credit * self.fx_rate)
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self._journal_status() == Journal.POSTED:
            raise ValidationError("Lines of a posted journal cannot be deleted.")
        return super().delete(*args, **kwargs)


class AuditLog(models.Model):
    """Append-only record of who did what. Rows can be added, never changed or removed."""

    entity = models.ForeignKey(Entity, on_delete=models.PROTECT, related_name="+")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.PROTECT, related_name="+")
    action = models.CharField(max_length=40)
    object_type = models.CharField(max_length=40)
    object_id = models.PositiveBigIntegerField()
    detail = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-id"]

    def save(self, *args, **kwargs):
        if self.pk:
            raise ValidationError("Audit log entries cannot be changed.")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValidationError("Audit log entries cannot be deleted.")
