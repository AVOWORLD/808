from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.db.models import Count
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.dateparse import parse_date
from django.views.decorators.http import require_POST

from core.models import Entity

from . import analytics, services
from .forms import JournalForm, LineFormSet, ReverseForm
from .models import Account, AuditLog, Journal


def entity_required(view):
    """Login needed, and the user must belong to at least one entity."""

    @wraps(view)
    @login_required
    def wrapper(request, *args, **kwargs):
        if request.membership is None:
            return render(request, "ledger/no_entity.html", status=403)
        return view(request, *args, **kwargs)

    return wrapper


def _errors(exc):
    return exc.messages if isinstance(exc, ValidationError) else [str(exc)]


@entity_required
def dashboard(request):
    entity = request.membership.entity
    journals = Journal.objects.filter(entity=entity)
    counts = {row["status"]: row["n"] for row in journals.values("status").annotate(n=Count("id"))}
    rows, dr, cr = services.trial_balance(entity)
    return render(
        request,
        "ledger/dashboard.html",
        {
            "drafts": counts.get(Journal.DRAFT, 0),
            "posted": counts.get(Journal.POSTED, 0),
            "recent": journals.select_related("created_by")[:8],
            "tb_accounts": len(rows),
            "tb_total": dr,
            "tb_balanced": dr == cr,
            "audit": AuditLog.objects.filter(entity=entity).select_related("user")[:6],
            "income_expense": analytics.income_expense_figure(entity),
        },
    )


@login_required
@require_POST
def switch_entity(request):
    entity_id = request.POST.get("entity")
    if request.user.memberships.filter(entity_id=entity_id).exists():
        request.session["entity_id"] = int(entity_id)
    return redirect("dashboard")


@entity_required
def accounts(request):
    entity = request.membership.entity
    items = list(Account.objects.filter(entity=entity).select_related("parent"))
    depth = {}
    for a in items:
        d, p = 0, a.parent
        while p is not None:
            d, p = d + 1, p.parent
        depth[a.pk] = d
    for a in items:
        a.depth = depth[a.pk]
    return render(request, "ledger/accounts.html", {"accounts": items})


@entity_required
def journals(request):
    entity = request.membership.entity
    status = request.GET.get("status")
    qs = Journal.objects.filter(entity=entity).select_related("created_by")
    if status in (Journal.DRAFT, Journal.POSTED):
        qs = qs.filter(status=status)
    return render(request, "ledger/journal_list.html", {"journals": qs[:200], "status": status})


@entity_required
def journal_new(request):
    membership = request.membership
    entity = membership.entity
    if not membership.can_submit:
        raise PermissionDenied
    form = JournalForm(request.POST or None)
    formset = LineFormSet(request.POST or None, form_kwargs={"entity": entity})
    if request.method == "POST" and form.is_valid() and formset.is_valid():
        lines = [f.cleaned_data for f in formset if f.cleaned_data.get("account")]
        try:
            journal = services.create_draft(
                entity=entity,
                user=request.user,
                date=form.cleaned_data["date"],
                memo=form.cleaned_data["memo"],
                reference=form.cleaned_data["reference"],
                lines=lines,
            )
        except (ValidationError, PermissionDenied) as exc:
            for msg in _errors(exc):
                form.add_error(None, msg)
        else:
            if "post" in request.POST and membership.can_post:
                try:
                    services.post_journal(journal, request.user)
                    messages.success(request, f"{journal} posted.")
                except ValidationError as exc:
                    messages.error(request, " ".join(exc.messages) + " The journal was saved as a draft.")
            else:
                messages.success(request, "Draft saved.")
            return redirect("journal_detail", pk=journal.pk)
    return render(request, "ledger/journal_form.html", {"form": form, "formset": formset, "can_post": membership.can_post})


@entity_required
def journal_detail(request, pk):
    entity = request.membership.entity
    journal = get_object_or_404(Journal.objects.select_related("created_by", "posted_by"), pk=pk, entity=entity)
    lines = journal.lines.select_related("account", "currency")
    dr, cr = journal.totals
    return render(
        request,
        "ledger/journal_detail.html",
        {
            "journal": journal,
            "lines": lines,
            "dr": dr,
            "cr": cr,
            "reverse_form": ReverseForm(),
            "audit": AuditLog.objects.filter(entity=entity, object_type="Journal", object_id=journal.pk).select_related("user"),
        },
    )


@entity_required
@require_POST
def journal_action(request, pk, action):
    entity = request.membership.entity
    journal = get_object_or_404(Journal, pk=pk, entity=entity)
    try:
        if action == "post":
            services.post_journal(journal, request.user)
            messages.success(request, f"{journal} posted.")
        elif action == "reverse":
            form = ReverseForm(request.POST)
            rev = services.reverse_journal(journal, request.user, date=form.cleaned_data["date"] if form.is_valid() else None)
            messages.success(request, f"Reversed with {rev}.")
            return redirect("journal_detail", pk=rev.pk)
        elif action == "delete":
            if journal.status != Journal.DRAFT:
                raise ValidationError("Only drafts can be deleted.")
            if not (request.membership.can_post or journal.created_by_id == request.user.pk):
                raise PermissionDenied
            services.log(entity, request.user, "delete_draft", journal, journal.memo)
            journal.delete()
            messages.success(request, "Draft deleted.")
            return redirect("journals")
        else:
            raise ValidationError("Unknown action.")
    except ValidationError as exc:
        messages.error(request, " ".join(exc.messages))
    except PermissionDenied as exc:
        messages.error(request, str(exc) or "Not allowed.")
    return redirect("journal_detail", pk=journal.pk)


@entity_required
def trial_balance(request):
    entity = request.membership.entity
    as_of = parse_date(request.GET.get("as_of", "") or "")
    rows, dr, cr = services.trial_balance(entity, as_of)
    return render(
        request,
        "ledger/trial_balance.html",
        {"rows": rows, "total_debit": dr, "total_credit": cr, "balanced": dr == cr, "as_of": as_of},
    )


@entity_required
def analytics_page(request):
    entity = request.membership.entity
    return render(
        request,
        "ledger/analytics.html",
        {
            "income_expense": analytics.income_expense_figure(entity),
            "stockpile": analytics.stockpile_value_figure(entity),
        },
    )
