from django.urls import path

from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("entity/switch/", views.switch_entity, name="switch_entity"),
    path("accounts/", views.accounts, name="accounts"),
    path("journals/", views.journals, name="journals"),
    path("journals/new/", views.journal_new, name="journal_new"),
    path("journals/<int:pk>/", views.journal_detail, name="journal_detail"),
    path("journals/<int:pk>/<str:action>/", views.journal_action, name="journal_action"),
    path("analytics/", views.analytics_page, name="analytics"),
    path("reports/trial-balance/", views.trial_balance, name="trial_balance"),
]
