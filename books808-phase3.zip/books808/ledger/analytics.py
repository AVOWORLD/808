"""Chart data and Plotly figures built from posted journals (base currency of the entity)."""

import json
from collections import defaultdict
from decimal import Decimal

import plotly.graph_objects as go
from django.db.models import Sum
from django.db.models.functions import TruncMonth

from .models import ZERO, Account, Journal, JournalLine

BLUE, OCHRE, CLAY, INK = "#2E86AB", "#C97B4A", "#3F6259", "#1C2B2E"


def _posted(entity):
    return JournalLine.objects.filter(journal__entity=entity, journal__status=Journal.POSTED)


def monthly_income_expense(entity):
    rows = (
        _posted(entity)
        .filter(account__type__in=[Account.INCOME, Account.EXPENSE])
        .annotate(m=TruncMonth("journal__date"))
        .values("m", "account__type")
        .annotate(d=Sum("base_debit"), c=Sum("base_credit"))
    )
    income, expense = defaultdict(Decimal), defaultdict(Decimal)
    for r in rows:
        d, c = r["d"] or ZERO, r["c"] or ZERO
        if r["account__type"] == Account.INCOME:
            income[r["m"]] += c - d
        else:
            expense[r["m"]] += d - c
    months = sorted(set(income) | set(expense))
    return months, [income[m] for m in months], [expense[m] for m in months]


def stockpile_value_series(entity):
    """Running balance of the stockpile inventory accounts (code 1200 and the accounts under it)."""
    header = Account.objects.filter(entity=entity, code="1200").first()
    if header is None:
        return [], []
    ids = [header.pk, *Account.objects.filter(parent=header).values_list("pk", flat=True)]
    rows = (
        _posted(entity)
        .filter(account_id__in=ids)
        .values("journal__date")
        .annotate(d=Sum("base_debit"), c=Sum("base_credit"))
        .order_by("journal__date")
    )
    dates, running, total = [], [], ZERO
    for r in rows:
        total += (r["d"] or ZERO) - (r["c"] or ZERO)
        dates.append(r["journal__date"])
        running.append(total)
    return dates, running


def _base_layout(fig, title, currency):
    fig.update_layout(
        title=dict(text=title, font=dict(size=16, color=INK)),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="system-ui, sans-serif", color=INK),
        margin=dict(l=56, r=16, t=48, b=40),
        height=320,
        legend=dict(orientation="h", y=-0.2),
        yaxis=dict(title=currency, gridcolor="#d9d4c8", zeroline=True, zerolinecolor="#9aa5a3", tickformat=",.0f"),
        xaxis=dict(showgrid=False),
    )
    return fig


def _as_dict(fig):
    return json.loads(fig.to_json())


def income_expense_figure(entity):
    months, income, expense = monthly_income_expense(entity)
    if not months:
        return None
    ccy = entity.base_currency_id
    x = [m.strftime("%b %Y") for m in months]
    fig = go.Figure(
        [
            go.Bar(name="Income", x=x, y=[float(v) for v in income], marker_color=BLUE),
            go.Bar(name="Expenses", x=x, y=[float(v) for v in expense], marker_color=OCHRE),
        ]
    )
    fig.update_layout(barmode="group")
    return _as_dict(_base_layout(fig, "Income and expenses by month", ccy))


def stockpile_value_figure(entity):
    dates, running = stockpile_value_series(entity)
    if not dates:
        return None
    ccy = entity.base_currency_id
    fig = go.Figure(
        go.Scatter(
            x=[d.isoformat() for d in dates],
            y=[float(v) for v in running],
            mode="lines+markers",
            line=dict(color=CLAY, width=2, shape="hv"),
            name="Stockpile inventory",
        )
    )
    return _as_dict(_base_layout(fig, "Stockpile inventory value over time", ccy))
