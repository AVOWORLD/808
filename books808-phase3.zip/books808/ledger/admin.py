from django.contrib import admin

from .models import Account, AuditLog, Journal


@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "type", "entity", "is_postable", "is_active")
    list_filter = ("entity", "type")
    search_fields = ("code", "name")


class ReadOnlyAdmin(admin.ModelAdmin):
    """Journals and the audit log are written through the app's services only."""

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Journal)
class JournalAdmin(ReadOnlyAdmin):
    list_display = ("__str__", "entity", "date", "memo", "status")
    list_filter = ("entity", "status")


@admin.register(AuditLog)
class AuditLogAdmin(ReadOnlyAdmin):
    list_display = ("created_at", "entity", "user", "action", "object_type", "object_id")
    list_filter = ("entity", "action")
