from datetime import date
from decimal import Decimal, InvalidOperation

from django.contrib import messages
from django.core.exceptions import PermissionDenied, ValidationError
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from ledger.models import ZERO, Account
from ledger.views import entity_required

from . import charts, services
from .forms import AddAccountForm, BudgetForm
from .models import Budget, add_months


def _msgs(exc):
    return " ".join(exc.messages) if isinstance(exc, ValidationError) else (str(exc) or "Not allowed.")


def _budget(request, pk):
    return get_object_or_404(Budget, pk=pk, entity=request.membership.entity)


@entity_required
def budget_list(request):
    membership = request.membership
    form = BudgetForm()
    if request.method == "POST":
        if not membership.can_post:
            raise PermissionDenied
        form = BudgetForm(request.POST)
        if form.is_valid():
            try:
                budget = services.create_budget(
                    entity=membership.entity, user=request.user, name=form.cleaned_data["name"], start_date=form.cleaned_data["start_date"]
                )
            except (ValidationError, PermissionDenied) as exc:
                form.add_error(None, _msgs(exc))
            else:
                messages.success(request, f"{budget} created. Add accounts to start planning.")
                return redirect("budget_detail", pk=budget.pk)
    return render(request, "budgets/budget_list.html", {"budgets": Budget.objects.filter(entity=membership.entity), "form": form})


@entity_required
def budget_detail(request, pk):
    budget = _budget(request, pk)
    months = budget.months
    by_account = {}
    for line in budget.lines.select_related("account"):
        by_account.setdefault(line.account_id, {"account": line.account, "cells": {}})["cells"][line.month] = line.amount
    sections = []
    for kind, title in ((Account.INCOME, "Income"), (Account.EXPENSE, "Expenses")):
        rows = []
        for entry in sorted((e for e in by_account.values() if e["account"].type == kind), key=lambda e: e["account"].code):
            cells = [{"month": m, "value": entry["cells"].get(m, ZERO), "name": f"a_{entry['account'].pk}_{m:%Y-%m}"} for m in months]
            rows.append({"account": entry["account"], "cells": cells, "total": sum((c["value"] for c in cells), ZERO)})
        col = [sum((r["cells"][i]["value"] for r in rows), ZERO) for i in range(12)]
        sections.append({"kind": kind, "title": title, "rows": rows, "col": col, "total": sum(col, ZERO)})
    net = [sections[0]["col"][i] - sections[1]["col"][i] for i in range(12)]
    can_edit = request.membership.can_post
    return render(request, "budgets/budget_grid.html", {
        "budget": budget, "months": months, "sections": sections, "net": net, "net_total": sum(net, ZERO),
        "can_edit": can_edit, "add_form": AddAccountForm(budget=budget) if can_edit else None,
    })


@entity_required
@require_POST
def budget_save(request, pk):
    budget = _budget(request, pk)
    wanted = {}
    try:
        for key, raw in request.POST.items():
            if not key.startswith("a_"):
                continue
            _, acct, ym = key.split("_")
            year, month = ym.split("-")
            raw = raw.strip().replace(",", "") or "0"
            try:
                value = Decimal(raw)
            except InvalidOperation:
                raise ValidationError(f"'{raw}' isn't a valid amount.")
            wanted[(int(acct), date(int(year), int(month), 1))] = value
        count = services.save_amounts(budget, request.user, wanted)
        messages.success(request, f"Saved. {count} amount(s) changed." if count else "Nothing changed.")
    except (ValidationError, PermissionDenied, ValueError) as exc:
        messages.error(request, _msgs(exc) if not isinstance(exc, ValueError) else "Something in the grid wasn't a valid amount. Nothing was saved.")
    return redirect("budget_detail", pk=pk)


@entity_required
@require_POST
def budget_add_account(request, pk):
    budget = _budget(request, pk)
    form = AddAccountForm(request.POST, budget=budget)
    if form.is_valid():
        try:
            services.add_account(budget, request.user, form.cleaned_data["account"], form.cleaned_data["annual"])
            messages.success(request, f"{form.cleaned_data['account']} added.")
        except (ValidationError, PermissionDenied) as exc:
            messages.error(request, _msgs(exc))
    else:
        messages.error(request, "Choose an account to add (and use a valid yearly amount, or leave it blank).")
    return redirect("budget_detail", pk=pk)


@entity_required
@require_POST
def budget_remove_account(request, pk, account_id):
    budget = _budget(request, pk)
    account = get_object_or_404(Account, pk=account_id, entity=budget.entity)
    try:
        services.remove_account(budget, request.user, account)
        messages.success(request, f"{account} removed from the budget.")
    except (ValidationError, PermissionDenied) as exc:
        messages.error(request, _msgs(exc))
    return redirect("budget_detail", pk=pk)


@entity_required
def budget_report(request, pk):
    budget = _budget(request, pk)
    months = budget.months
    today = timezone.localdate().replace(day=1)
    default = months[0] if today < months[0] else months[-1] if today > months[-1] else today
    through = default
    raw = request.GET.get("through", "")
    if raw:
        match = [m for m in months if f"{m:%Y-%m}" == raw]
        through = match[0] if match else default
    rep = services.report(budget, through)
    currency = budget.entity.base_currency_id
    return render(request, "budgets/budget_report.html", {
        "budget": budget, "rep": rep, "through": through, "months": months, "currency": currency,
        "chart_categories": charts.expenses_by_category(rep, currency), "chart_monthly": charts.monthly_net(rep, currency),
        "income_rows": [r for r in rep["rows"] if r["account"].type == Account.INCOME],
        "expense_rows": [r for r in rep["rows"] if r["account"].type == Account.EXPENSE],
    })
