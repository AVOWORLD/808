from decimal import Decimal

from django import forms
from django.utils import timezone

from ledger.models import Account


class BudgetForm(forms.Form):
    name = forms.CharField(max_length=80, help_text="For example: FY2027 budget.")
    start_date = forms.DateField(
        widget=forms.DateInput(attrs={"type": "date"}), initial=lambda: timezone.localdate().replace(day=1),
        help_text="The first of twelve months. Pick your financial year start.",
    )


class AddAccountForm(forms.Form):
    account = forms.ModelChoiceField(queryset=Account.objects.none())
    annual = forms.DecimalField(
        max_digits=18, decimal_places=2, min_value=Decimal("0"), required=False, label="Yearly amount",
        help_text="Optional. Spread evenly over the twelve months; you can adjust each month after.",
    )

    def __init__(self, *args, budget, **kwargs):
        super().__init__(*args, **kwargs)
        used = budget.lines.values_list("account_id", flat=True)
        self.fields["account"].queryset = Account.objects.filter(
            entity=budget.entity, type__in=[Account.INCOME, Account.EXPENSE], is_active=True, is_postable=True
        ).exclude(pk__in=list(used))
