from django.urls import path

from . import views

urlpatterns = [
    path("budgets/", views.budget_list, name="budget_list"),
    path("budgets/<int:pk>/", views.budget_detail, name="budget_detail"),
    path("budgets/<int:pk>/save/", views.budget_save, name="budget_save"),
    path("budgets/<int:pk>/add-account/", views.budget_add_account, name="budget_add_account"),
    path("budgets/<int:pk>/remove-account/<int:account_id>/", views.budget_remove_account, name="budget_remove_account"),
    path("budgets/<int:pk>/report/", views.budget_report, name="budget_report"),
]
