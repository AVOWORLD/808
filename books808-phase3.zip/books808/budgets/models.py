from datetime import date, timedelta

from django.conf import settings
from django.db import models

from core.models import Entity
from ledger.models import ZERO, Account


def add_months(d, n):
    """First day of the month n months after d's month."""
    index = d.year * 12 + (d.month - 1) + n
    return date(index // 12, index % 12 + 1, 1)


class Budget(models.Model):
    """A twelve-month plan by account and month, in the entity's base currency."""

    entity = models.ForeignKey(Entity, on_delete=models.CASCADE, related_name="budgets")
    name = models.CharField(max_length=80, help_text="For example: FY2027 budget.")
    start_date = models.DateField(help_text="First month of the twelve. Any date in that month works.")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-start_date", "name"]
        constraints = [models.UniqueConstraint(fields=["entity", "name"], name="uniq_budget_name_per_entity")]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        self.start_date = self.start_date.replace(day=1)
        super().save(*args, **kwargs)

    @property
    def months(self):
        return [add_months(self.start_date, i) for i in range(12)]

    @property
    def end_date(self):
        return add_months(self.start_date, 12) - timedelta(days=1)


class BudgetLine(models.Model):
    budget = models.ForeignKey(Budget, on_delete=models.CASCADE, related_name="lines")
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+")
    month = models.DateField(help_text="First day of the month.")
    amount = models.DecimalField(max_digits=18, decimal_places=2, default=ZERO)

    class Meta:
        ordering = ["account__code", "month"]
        constraints = [
            models.UniqueConstraint(fields=["budget", "account", "month"], name="uniq_budget_line"),
            models.CheckConstraint(condition=models.Q(amount__gte=0), name="budget_amount_non_negative"),
        ]
