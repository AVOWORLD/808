"""Budget rules. Budgets are plans, not postings: nothing here writes to the ledger.

Amounts are positive numbers for both income and expense accounts, in the entity's base currency.
Actuals come from posted journals only."""

from datetime import timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Sum
from django.db.models.functions import TruncMonth

from ledger import services as ledger
from ledger.models import ZERO, Account, Journal, JournalLine, money

from .models import Budget, BudgetLine, add_months

PLANNED_TYPES = (Account.INCOME, Account.EXPENSE)


@transaction.atomic
def create_budget(*, entity, user, name, start_date):
    ledger.require_post(user, entity)
    name = (name or "").strip()
    if not name:
        raise ValidationError("Give the budget a name.")
    if Budget.objects.filter(entity=entity, name__iexact=name).exists():
        raise ValidationError("A budget with this name already exists.")
    budget = Budget.objects.create(entity=entity, name=name, start_date=start_date, created_by=user)
    ledger.log(entity, user, "create_budget", budget, name)
    return budget


def spread(annual):
    """Split a yearly amount over twelve months in cents; any remainder lands in the last month."""
    annual = money(annual)
    each = money(annual / 12)
    parts = [each] * 11
    parts.append(annual - sum(parts, ZERO))
    return parts


@transaction.atomic
def add_account(budget, user, account, annual=None):
    ledger.require_post(user, budget.entity)
    if account.entity_id != budget.entity_id or account.type not in PLANNED_TYPES or not account.is_active or not account.is_postable:
        raise ValidationError("Budgets cover active income and expense accounts of this entity.")
    if budget.lines.filter(account=account).exists():
        raise ValidationError(f"{account.code} {account.name} is already in this budget.")
    if annual is not None and annual < 0:
        raise ValidationError("Budget amounts can't be negative.")
    amounts = spread(annual) if annual else [ZERO] * 12
    BudgetLine.objects.bulk_create(
        [BudgetLine(budget=budget, account=account, month=m, amount=a) for m, a in zip(budget.months, amounts)]
    )
    ledger.log(budget.entity, user, "budget_add_account", budget, f"{account.code} {annual or 0}")


@transaction.atomic
def remove_account(budget, user, account):
    ledger.require_post(user, budget.entity)
    deleted, _ = budget.lines.filter(account=account).delete()
    if not deleted:
        raise ValidationError("That account isn't in this budget.")
    ledger.log(budget.entity, user, "budget_remove_account", budget, account.code)


@transaction.atomic
def save_amounts(budget, user, amounts):
    """amounts: {(account_id, month_date): Decimal}. Only existing lines are updated."""
    ledger.require_post(user, budget.entity)
    if any(v < 0 for v in amounts.values()):
        raise ValidationError("Budget amounts can't be negative.")
    lines = {(l.account_id, l.month): l for l in budget.lines.all()}
    changed = []
    for key, value in amounts.items():
        line = lines.get(key)
        if line is not None and line.amount != money(value):
            line.amount = money(value)
            changed.append(line)
    if changed:
        BudgetLine.objects.bulk_update(changed, ["amount"])
        ledger.log(budget.entity, user, "budget_save", budget, f"{len(changed)} amounts changed")
    return len(changed)


def _signed(account_type, debit, credit):
    """Actual result for an account: income earns on the credit side, expenses on the debit side."""
    return (credit - debit) if account_type == Account.INCOME else (debit - credit)


def report(budget, through):
    """Budget vs actual from the budget's start through the end of the month `through` (a first-of-month date)."""
    entity = budget.entity
    months = [m for m in budget.months if m <= through]
    start, end = budget.start_date, add_months(through, 1) - timedelta(days=1)

    planned = {}
    for line in budget.lines.filter(month__lte=through).select_related("account"):
        planned[line.account_id] = planned.get(line.account_id, ZERO) + line.amount
    budget_accounts = {l.account_id: l.account for l in budget.lines.select_related("account")}

    posted = JournalLine.objects.filter(
        journal__entity=entity, journal__status=Journal.POSTED, journal__date__gte=start, journal__date__lte=end,
        account__type__in=PLANNED_TYPES,
    )
    actual, monthly = {}, {}
    for r in posted.annotate(m=TruncMonth("journal__date")).values("account_id", "account__type", "m").annotate(d=Sum("base_debit"), c=Sum("base_credit")):
        value = _signed(r["account__type"], r["d"] or ZERO, r["c"] or ZERO)
        actual[r["account_id"]] = actual.get(r["account_id"], ZERO) + value
        key = (r["account__type"], r["m"].date() if hasattr(r["m"], "date") else r["m"])
        monthly[key] = monthly.get(key, ZERO) + value

    extra = {a.pk: a for a in Account.objects.filter(pk__in=[k for k, v in actual.items() if v and k not in budget_accounts])}
    rows = []
    for account in sorted({**budget_accounts, **extra}.values(), key=lambda a: a.code):
        b, a = planned.get(account.pk, ZERO), actual.get(account.pk, ZERO)
        variance = (a - b) if account.type == Account.INCOME else (b - a)
        rows.append({
            "account": account, "budget": b, "actual": a, "variance": variance,
            "pct": (a / b * 100).quantize(Decimal("0.1")) if b else None,
            "budgeted": account.pk in budget_accounts, "favourable": variance >= 0,
        })

    def total(kind):
        sel = [r for r in rows if r["account"].type == kind]
        b, a = sum((r["budget"] for r in sel), ZERO), sum((r["actual"] for r in sel), ZERO)
        return {"budget": b, "actual": a, "variance": (a - b) if kind == Account.INCOME else (b - a)}

    income, expense = total(Account.INCOME), total(Account.EXPENSE)
    series = []
    for m in months:
        bi = sum((l.amount for l in budget.lines.filter(month=m, account__type=Account.INCOME)), ZERO)
        be = sum((l.amount for l in budget.lines.filter(month=m, account__type=Account.EXPENSE)), ZERO)
        series.append({
            "month": m, "budget_net": bi - be,
            "actual_net": monthly.get((Account.INCOME, m), ZERO) - monthly.get((Account.EXPENSE, m), ZERO),
        })
    return {
        "rows": rows, "income": income, "expense": expense,
        "net": {"budget": income["budget"] - expense["budget"], "actual": income["actual"] - expense["actual"]},
        "months": months, "series": series, "start": start, "end": end,
    }
