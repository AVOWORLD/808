"""DEMO budget plus a few DEMO expense claims, so the Budgets and Expenses pages have something to show.

Invented MWK numbers. Run `seed_demo` first so there are journals to compare the budget against.
Development databases only.
"""

from datetime import date, timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone

from billing.models import TaxRate
from budgets import services as budget_services
from budgets.models import Budget
from core.models import Currency, Entity, Membership
from expenses import services as expense_services
from expenses.models import Expense
from ledger.models import Account

PLAN = [("4010", 6_000_000), ("4020", 5_000_000), ("5010", 1_200_000), ("5020", 3_600_000), ("5030", 600_000), ("5040", 1_800_000), ("5050", 360_000)]


class Command(BaseCommand):
    help = "Create a DEMO budget and DEMO expense claims for the Malawi entity (development only)."

    def add_arguments(self, parser):
        parser.add_argument("--username", required=True, help="An admin user in the Malawi entity.")

    def handle(self, *args, **opts):
        user = get_user_model().objects.filter(username=opts["username"]).first()
        entity = Entity.objects.filter(name="808 Computing Malawi").first()
        if user is None or entity is None:
            raise CommandError("Run seed_malawi first and pass an existing --username.")
        if Budget.objects.filter(entity=entity, name__startswith="DEMO").exists():
            self.stdout.write("Demo planning data already exists; nothing to do.")
            return
        acct = {a.code: a for a in Account.objects.filter(entity=entity)}
        budget = budget_services.create_budget(entity=entity, user=user, name="DEMO FY 2026/27", start_date=date(2026, 7, 1))
        for code, annual in PLAN:
            budget_services.add_account(budget, user, acct[code], annual)

        staff, _ = get_user_model().objects.get_or_create(username="demo.staff")
        Membership.objects.get_or_create(user=staff, entity=entity, defaults={"role": Membership.SUBMITTER})
        mwk, vat = Currency.objects.get(code="MWK"), TaxRate.objects.get(entity=entity, name__startswith="VAT standard")
        today = timezone.localdate()

        def claim(days_ago, text, code, amount, paid_by="claimant", tax=True):
            return expense_services.submit_expense(
                entity=entity, user=staff, date=today - timedelta(days=days_ago), description=f"DEMO: {text}", account=acct[code],
                amount=amount, currency=mwk, paid_by=paid_by, tax_rate=vat if tax else None,
            )

        expense_services.reimburse_expense(
            expense_services.approve_expense(claim(12, "Taxi to Kanengo silos site visit", "5030", 46_600), user),
            user, acct["1010"], today - timedelta(days=5),
        )
        expense_services.approve_expense(claim(6, "Fuel for survey drive", "5030", 93_200), user)
        expense_services.approve_expense(claim(4, "Drone battery rental", "5040", 233_000, paid_by="company"), user, paid_from=acct["1010"])
        claim(1, "Chamber of Mines lunch meeting", "5030", 58_250)
        self.stdout.write(self.style.SUCCESS("Created a demo budget and 4 demo expense claims (reimbursed, to reimburse, company-paid, pending)."))
