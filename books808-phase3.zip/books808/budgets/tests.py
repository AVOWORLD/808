from datetime import date
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse

from core.models import Currency, Entity, Membership
from ledger import services as ledger
from ledger.models import Account

from . import services
from .models import Budget, BudgetLine, add_months

User = get_user_model()
D = Decimal


class Base(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_malawi", verbosity=0)
        cls.entity = Entity.objects.get(name="808 Computing Malawi")
        cls.mwk = Currency.objects.get(code="MWK")
        mk = lambda name, role: (lambda u: (Membership.objects.create(user=u, entity=cls.entity, role=role), u)[1])(User.objects.create_user(name, password="pw"))
        cls.fin, cls.sub, cls.view = mk("fin", "finance"), mk("sub", "submitter"), mk("view", "viewer")
        cls.acct = {a.code: a for a in Account.objects.filter(entity=cls.entity)}

    def budget(self, start=date(2026, 7, 1), name="FY27"):
        return services.create_budget(entity=self.entity, user=self.fin, name=name, start_date=start)

    def post(self, when, debit, credit, amount, status="posted"):
        j = ledger.create_draft(
            entity=self.entity, user=self.fin, date=when, memo="test",
            lines=[{"account": self.acct[debit], "currency": self.mwk, "debit": amount},
                   {"account": self.acct[credit], "currency": self.mwk, "credit": amount}],
        )
        return ledger.post_journal(j, self.fin) if status == "posted" else j


class Planning(Base):
    def test_months_snap_to_the_first_and_run_twelve(self):
        b = self.budget(start=date(2026, 7, 19))
        self.assertEqual(b.start_date, date(2026, 7, 1))
        self.assertEqual((b.months[0], b.months[-1], b.end_date), (date(2026, 7, 1), date(2027, 6, 1), date(2027, 6, 30)))
        self.assertEqual(add_months(date(2026, 12, 1), 1), date(2027, 1, 1))

    def test_spread_adds_up_exactly(self):
        self.assertEqual(services.spread(D("1200000")), [D("100000.00")] * 12)
        parts = services.spread(D("100"))
        self.assertEqual(sum(parts), D("100.00"))
        self.assertEqual((parts[0], parts[-1]), (D("8.33"), D("8.37")))

    def test_add_account_validations_and_spread(self):
        b = self.budget()
        services.add_account(b, self.fin, self.acct["5010"], D("1200000"))
        self.assertEqual(b.lines.filter(account=self.acct["5010"]).count(), 12)
        self.assertEqual(b.lines.first().amount, D("100000.00"))
        with self.assertRaises(ValidationError):
            services.add_account(b, self.fin, self.acct["5010"])  # twice
        with self.assertRaises(ValidationError):
            services.add_account(b, self.fin, self.acct["1010"])  # an asset
        with self.assertRaises(ValidationError):
            services.add_account(b, self.fin, self.acct["5000"])  # a header
        other = Entity.objects.create(name="808 Kenya", country="KE", base_currency=Currency.objects.get(code="KES"))
        foreign = Account.objects.create(entity=other, code="5010", name="Cloud", type="expense")
        with self.assertRaises(ValidationError):
            services.add_account(b, self.fin, foreign)

    def test_names_unique_and_required(self):
        self.budget()
        with self.assertRaises(ValidationError):
            self.budget(name="fy27")
        with self.assertRaises(ValidationError):
            self.budget(name="  ")

    def test_only_finance_can_change_budgets(self):
        b = self.budget()
        with self.assertRaises(PermissionDenied):
            services.add_account(b, self.sub, self.acct["5010"])
        with self.assertRaises(PermissionDenied):
            services.create_budget(entity=self.entity, user=self.view, name="x", start_date=date(2026, 7, 1))

    def test_save_amounts_updates_only_existing_lines_and_rejects_negatives(self):
        b = self.budget()
        services.add_account(b, self.fin, self.acct["5010"])
        key = (self.acct["5010"].pk, date(2026, 7, 1))
        self.assertEqual(services.save_amounts(b, self.fin, {key: D("500.5"), (999, date(2026, 7, 1)): D("1")}), 1)
        self.assertEqual(BudgetLine.objects.get(budget=b, account=self.acct["5010"], month=date(2026, 7, 1)).amount, D("500.50"))
        with self.assertRaises(ValidationError):
            services.save_amounts(b, self.fin, {key: D("-1")})

    def test_remove_account(self):
        b = self.budget()
        services.add_account(b, self.fin, self.acct["5010"], D("12"))
        services.remove_account(b, self.fin, self.acct["5010"])
        self.assertFalse(b.lines.exists())
        with self.assertRaises(ValidationError):
            services.remove_account(b, self.fin, self.acct["5010"])


class BudgetVsActual(Base):
    def setUp(self):
        self.b = self.budget()
        services.add_account(self.b, self.fin, self.acct["5010"], D("1200000"))   # 100,000 a month
        services.add_account(self.b, self.fin, self.acct["4010"], D("6000000"))   # 500,000 a month
        self.post(date(2026, 7, 10), "1010", "4010", "6000000")        # income in July
        self.post(date(2026, 8, 15), "5010", "1010", "900000")         # overspend in August
        self.post(date(2026, 9, 5), "5030", "1010", "50000")           # expense nobody budgeted

    def row(self, rep, code):
        return next(r for r in rep["rows"] if r["account"].code == code)

    def test_year_to_date_numbers_and_variance_direction(self):
        rep = services.report(self.b, date(2026, 10, 1))
        cloud, fees = self.row(rep, "5010"), self.row(rep, "4010")
        self.assertEqual((cloud["budget"], cloud["actual"], cloud["variance"]), (D("400000.00"), D("900000.00"), D("-500000.00")))
        self.assertFalse(cloud["favourable"])
        self.assertEqual(cloud["pct"], D("225.0"))
        self.assertEqual((fees["budget"], fees["actual"], fees["variance"]), (D("2000000.00"), D("6000000.00"), D("4000000.00")))
        self.assertTrue(fees["favourable"])
        self.assertEqual(rep["net"]["actual"], D("6000000") - D("950000"))

    def test_through_month_limits_both_budget_and_actual(self):
        rep = services.report(self.b, date(2026, 7, 1))
        self.assertEqual(self.row(rep, "5010")["budget"], D("100000.00"))
        self.assertEqual(self.row(rep, "5010")["actual"], D("0"))
        self.assertEqual(self.row(rep, "4010")["actual"], D("6000000.00"))
        self.assertEqual(len(rep["series"]), 1)

    def test_unbudgeted_activity_is_shown_not_hidden(self):
        travel = self.row(services.report(self.b, date(2026, 10, 1)), "5030")
        self.assertEqual((travel["budgeted"], travel["budget"], travel["actual"], travel["pct"]), (False, D("0"), D("50000.00"), None))

    def test_drafts_reversals_and_out_of_period_are_handled(self):
        self.post(date(2026, 8, 20), "5010", "1010", "70000", status="draft")        # draft: ignored
        self.post(date(2026, 6, 30), "5010", "1010", "111000")                       # before the budget starts
        self.post(date(2027, 7, 1), "5010", "1010", "222000")                        # after it ends
        j = self.post(date(2026, 9, 9), "5010", "1010", "30000")
        ledger.reverse_journal(j, self.fin, date=date(2026, 9, 10))                   # nets to zero
        cloud = self.row(services.report(self.b, date(2027, 6, 1)), "5010")
        self.assertEqual(cloud["actual"], D("900000.00"))

    def test_monthly_net_series(self):
        series = services.report(self.b, date(2026, 8, 1))["series"]
        self.assertEqual([s["actual_net"] for s in series], [D("6000000.00"), D("-900000.00")])
        self.assertEqual(series[0]["budget_net"], D("400000.00"))


class Screens(Base):
    def setUp(self):
        self.b = self.budget()
        services.add_account(self.b, self.fin, self.acct["5010"], D("1200000"))
        services.add_account(self.b, self.fin, self.acct["4010"], D("2400000"))

    def test_pages_render_for_everyone_but_only_finance_sees_inputs(self):
        for user, inputs in (("fin", True), ("sub", False), ("view", False)):
            self.client.logout()
            self.client.login(username=user, password="pw")
            for name in ("budget_list",):
                self.assertEqual(self.client.get(reverse(name)).status_code, 200)
            grid = self.client.get(reverse("budget_detail", args=[self.b.pk]))
            self.assertEqual(grid.status_code, 200)
            self.assertEqual('name="a_' in grid.content.decode(), inputs, user)
            self.assertEqual(self.client.get(reverse("budget_report", args=[self.b.pk]) + "?through=2026-09").status_code, 200)

    def test_saving_the_grid(self):
        self.client.login(username="fin", password="pw")
        resp = self.client.post(reverse("budget_save", args=[self.b.pk]), {f"a_{self.acct['5010'].pk}_2026-08": "1,234.50", f"a_{self.acct['4010'].pk}_2026-08": ""})
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(BudgetLine.objects.get(budget=self.b, account=self.acct["5010"], month=date(2026, 8, 1)).amount, D("1234.50"))
        self.assertEqual(BudgetLine.objects.get(budget=self.b, account=self.acct["4010"], month=date(2026, 8, 1)).amount, D("0.00"))

    def test_bad_amount_saves_nothing(self):
        self.client.login(username="fin", password="pw")
        before = list(BudgetLine.objects.values_list("amount", flat=True))
        resp = self.client.post(reverse("budget_save", args=[self.b.pk]), {f"a_{self.acct['5010'].pk}_2026-08": "12abc", f"a_{self.acct['5010'].pk}_2026-09": "5"}, follow=True)
        self.assertContains(resp, "valid amount")
        self.assertEqual(list(BudgetLine.objects.values_list("amount", flat=True)), before)

    def test_submitter_cannot_save_and_other_entity_is_hidden(self):
        self.client.login(username="sub", password="pw")
        self.client.post(reverse("budget_save", args=[self.b.pk]), {f"a_{self.acct['5010'].pk}_2026-08": "9"})
        self.assertNotEqual(BudgetLine.objects.get(budget=self.b, account=self.acct["5010"], month=date(2026, 8, 1)).amount, D("9"))
        other = Entity.objects.create(name="808 Kenya", country="KE", base_currency=Currency.objects.get(code="KES"))
        ken = User.objects.create_user("ken", password="pw")
        Membership.objects.create(user=ken, entity=other, role="admin")
        self.client.logout()
        self.client.login(username="ken", password="pw")
        self.assertEqual(self.client.get(reverse("budget_detail", args=[self.b.pk])).status_code, 404)
        self.assertEqual(self.client.get(reverse("budget_report", args=[self.b.pk])).status_code, 404)

    def test_create_and_extend_through_the_screens(self):
        self.client.login(username="fin", password="pw")
        resp = self.client.post(reverse("budget_list"), {"name": "FY28", "start_date": "2027-07-01"})
        new = Budget.objects.get(name="FY28")
        self.assertRedirects(resp, reverse("budget_detail", args=[new.pk]))
        self.client.post(reverse("budget_add_account", args=[new.pk]), {"account": self.acct["5020"].pk, "annual": "1200"})
        self.assertEqual(new.lines.count(), 12)
        self.client.post(reverse("budget_remove_account", args=[new.pk, self.acct["5020"].pk]))
        self.assertEqual(new.lines.count(), 0)
