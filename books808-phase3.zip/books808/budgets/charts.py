import plotly.graph_objects as go

from ledger.analytics import BLUE, CLAY, OCHRE, _as_dict, _base_layout
from ledger.models import Account


def expenses_by_category(rep, currency):
    rows = [r for r in rep["rows"] if r["account"].type == Account.EXPENSE and (r["budget"] or r["actual"])]
    if not rows:
        return None
    names = [r["account"].name for r in rows]
    fig = go.Figure([
        go.Bar(name="Budget", x=names, y=[float(r["budget"]) for r in rows], marker_color=CLAY),
        go.Bar(name="Actual", x=names, y=[float(r["actual"]) for r in rows], marker_color=OCHRE),
    ])
    fig.update_layout(barmode="group")
    return _as_dict(_base_layout(fig, "Expenses: budget vs actual", currency))


def monthly_net(rep, currency):
    if not rep["series"] or not any(s["budget_net"] or s["actual_net"] for s in rep["series"]):
        return None
    x = [s["month"].strftime("%b %Y") for s in rep["series"]]
    fig = go.Figure([
        go.Scatter(name="Budget", x=x, y=[float(s["budget_net"]) for s in rep["series"]], mode="lines+markers", line=dict(color=CLAY, width=2, dash="dot")),
        go.Scatter(name="Actual", x=x, y=[float(s["actual_net"]) for s in rep["series"]], mode="lines+markers", line=dict(color=BLUE, width=3)),
    ])
    return _as_dict(_base_layout(fig, "Net result by month (income minus expenses)", currency))
