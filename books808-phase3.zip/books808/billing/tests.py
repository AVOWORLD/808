from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from core.models import Currency, Entity, ExchangeRate, Membership
from ledger import services as ledger
from ledger.models import Account, Journal

from . import services
from .models import BillingSettings, Contact, Document, Payment, TaxRate

User = get_user_model()
D = Decimal


class Base(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_malawi", verbosity=0)
        cls.entity = Entity.objects.get(name="808 Computing Malawi")
        cls.mwk, cls.usd = Currency.objects.get(code="MWK"), Currency.objects.get(code="USD")
        cls.fin = User.objects.create_user("fin", password="pw")
        cls.sub = User.objects.create_user("sub", password="pw")
        cls.view = User.objects.create_user("view", password="pw")
        for u, role in ((cls.fin, "finance"), (cls.sub, "submitter"), (cls.view, "viewer")):
            Membership.objects.create(user=u, entity=cls.entity, role=role)
        cls.acct = {a.code: a for a in Account.objects.filter(entity=cls.entity)}
        cls.vat = TaxRate.objects.get(entity=cls.entity, name__startswith="VAT standard")
        cls.customer = Contact.objects.create(entity=cls.entity, name="Sample Mine", kind="customer")
        cls.supplier = Contact.objects.create(entity=cls.entity, name="Cloud Co", kind="supplier")

    def invoice(self, price="1000", qty="1", currency=None, when=None, tax=True, user=None, **kw):
        when = when or date(2026, 11, 1)
        return services.create_document(
            entity=self.entity, user=user or self.fin, kind="invoice", contact=self.customer, date=when,
            due_date=kw.pop("due_date", when + timedelta(days=30)), currency=currency or self.mwk,
            lines=[{"description": "Pilot", "account": self.acct["4010"], "quantity": D(qty), "unit_price": D(price),
                    "tax_rate": self.vat if tax else None}], **kw,
        )

    def bill(self, price="500", when=None):
        when = when or date(2026, 11, 1)
        return services.create_document(
            entity=self.entity, user=self.fin, kind="bill", contact=self.supplier, date=when,
            due_date=when + timedelta(days=30), currency=self.mwk,
            lines=[{"description": "Hosting", "account": self.acct["5010"], "quantity": D(1), "unit_price": D(price), "tax_rate": self.vat}],
        )

    def pay(self, doc, amount, when=date(2026, 11, 5), **kw):
        kind = Payment.RECEIVED if doc.kind == "invoice" else Payment.PAID
        return services.record_payment(
            entity=self.entity, user=self.fin, kind=kind, contact=doc.contact, date=when, currency=doc.currency,
            bank_account=self.acct["1010"], allocations=[(doc, D(amount))], **kw,
        )

    def balances(self):
        rows, dr, cr = ledger.trial_balance(self.entity)
        return {r["account"].code: r["debit"] - r["credit"] for r in rows}, dr, cr


class IssuingDocuments(Base):
    def test_invoice_posts_balanced_journal_with_vat(self):
        doc = services.issue_document(self.invoice("1000"), self.fin)
        self.assertEqual((str(doc), doc.status), ("INV-0001", "issued"))
        self.assertEqual(doc.total, D("1165.00"))
        bal, dr, cr = self.balances()
        self.assertEqual(bal["1100"], D("1165.00"))
        self.assertEqual(bal["4010"], D("-1000.00"))
        self.assertEqual(bal["2100"], D("-165.00"))
        self.assertEqual(dr, cr)
        self.assertEqual(doc.journal.status, Journal.POSTED)
        self.assertEqual(doc.journal.source, "invoice")

    def test_bill_posts_to_expense_input_vat_and_payable(self):
        doc = services.issue_document(self.bill("500"), self.fin)
        self.assertEqual(str(doc), "BILL-0001")
        bal, dr, cr = self.balances()
        self.assertEqual((bal["5010"], bal["1300"], bal["2010"]), (D("500.00"), D("82.50"), D("-582.50")))
        self.assertEqual(dr, cr)

    def test_numbers_are_sequential_per_kind(self):
        a = services.issue_document(self.invoice(), self.fin)
        b = services.issue_document(self.invoice(), self.fin)
        c = services.issue_document(self.bill(), self.fin)
        self.assertEqual((a.number, b.number, c.number), (1, 2, 1))

    def test_lines_locked_once_issued(self):
        doc = services.issue_document(self.invoice(), self.fin)
        line = doc.lines.first()
        line.unit_price = D("1")
        with self.assertRaises(ValidationError):
            line.save()
        with self.assertRaises(ValidationError):
            line.delete()
        with self.assertRaises(ValidationError):
            services.issue_document(doc, self.fin)

    def test_roles_submitter_drafts_finance_issues(self):
        draft = self.invoice(user=self.sub)
        with self.assertRaises(PermissionDenied):
            services.issue_document(draft, self.sub)
        services.issue_document(draft, self.fin)
        with self.assertRaises(PermissionDenied):
            self.invoice(user=self.view)

    def test_wrong_account_type_or_contact_kind_refused(self):
        with self.assertRaises(ValidationError):
            services.create_document(
                entity=self.entity, user=self.fin, kind="invoice", contact=self.customer, date=date(2026, 11, 1),
                due_date=date(2026, 12, 1), currency=self.mwk,
                lines=[{"description": "x", "account": self.acct["5010"], "quantity": D(1), "unit_price": D(1), "tax_rate": None}],
            )
        with self.assertRaises(ValidationError):
            services.create_document(
                entity=self.entity, user=self.fin, kind="bill", contact=self.customer, date=date(2026, 11, 1),
                due_date=date(2026, 12, 1), currency=self.mwk,
                lines=[{"description": "x", "account": self.acct["5010"], "quantity": D(1), "unit_price": D(1), "tax_rate": None}],
            )

    def test_other_entity_data_refused(self):
        other = Entity.objects.create(name="808 Kenya", country="KE", base_currency=Currency.objects.get(code="KES"))
        Membership.objects.create(user=self.fin, entity=other, role="finance")
        foreign = Contact.objects.create(entity=other, name="Kenya Mine")
        with self.assertRaises(ValidationError):
            services.create_document(
                entity=self.entity, user=self.fin, kind="invoice", contact=foreign, date=date(2026, 11, 1),
                due_date=date(2026, 12, 1), currency=self.mwk,
                lines=[{"description": "x", "account": self.acct["4010"], "quantity": D(1), "unit_price": D(1), "tax_rate": None}],
            )

    def test_foreign_currency_odd_amounts_still_balance(self):
        ExchangeRate.objects.create(currency=self.usd, to_currency=self.mwk, date=date(2026, 10, 30), rate=D("1750.537"))
        doc = services.issue_document(self.invoice("33.33", qty="3", currency=self.usd), self.fin)
        self.assertEqual(doc.fx_rate, D("1750.537"))
        _, dr, cr = self.balances()
        self.assertEqual(dr, cr)

    def test_missing_rate_refuses_issue(self):
        with self.assertRaises(ValidationError):
            services.issue_document(self.invoice(currency=self.usd), self.fin)


class Payments(Base):
    def test_full_payment_clears_receivable(self):
        doc = services.issue_document(self.invoice("1000"), self.fin)
        self.pay(doc, "1165")
        doc = Document.objects.get(pk=doc.pk)
        self.assertTrue(doc.is_paid)
        self.assertEqual(doc.display_status, "paid")
        bal, dr, cr = self.balances()
        self.assertEqual(bal["1100"], D("0.00"))
        self.assertEqual(bal["1010"], D("1165.00"))
        self.assertEqual(dr, cr)

    def test_partial_payment_and_overpayment(self):
        doc = services.issue_document(self.invoice("1000"), self.fin)
        self.pay(doc, "500")
        self.assertEqual(Document.objects.get(pk=doc.pk).balance, D("665.00"))
        with self.assertRaises(ValidationError):
            self.pay(doc, "700")
        with self.assertRaises(ValidationError):
            self.pay(doc, "0")

    def test_bill_payment_reduces_payable(self):
        doc = services.issue_document(self.bill("500"), self.fin)
        self.pay(doc, "582.50")
        bal, dr, cr = self.balances()
        self.assertEqual((bal["2010"], bal["1010"]), (D("0.00"), D("-582.50")))
        self.assertEqual(dr, cr)

    def test_draft_cannot_be_paid_and_roles_enforced(self):
        draft = self.invoice()
        with self.assertRaises(ValidationError):
            self.pay(draft, "10")
        doc = services.issue_document(draft, self.fin)
        with self.assertRaises(PermissionDenied):
            services.record_payment(
                entity=self.entity, user=self.sub, kind="received", contact=doc.contact, date=date(2026, 11, 5),
                currency=self.mwk, bank_account=self.acct["1010"], allocations=[(doc, D("10"))],
            )

    def test_foreign_payment_books_exchange_gain(self):
        ExchangeRate.objects.create(currency=self.usd, to_currency=self.mwk, date=date(2026, 10, 1), rate=D("1750"))
        doc = services.issue_document(self.invoice("100", currency=self.usd, tax=False), self.fin)
        self.pay(doc, "100", fx_rate=D("1800"))
        bal, dr, cr = self.balances()
        self.assertEqual(bal["1100"], D("0.00"))
        self.assertEqual(bal["1010"], D("180000.00"))
        self.assertEqual(bal["4900"], D("-5000.00"))
        self.assertEqual(dr, cr)

    def test_foreign_payment_books_exchange_loss(self):
        ExchangeRate.objects.create(currency=self.usd, to_currency=self.mwk, date=date(2026, 10, 1), rate=D("1750"))
        doc = services.issue_document(self.invoice("100", currency=self.usd, tax=False), self.fin)
        self.pay(doc, "100", fx_rate=D("1700"))
        bal, dr, cr = self.balances()
        self.assertEqual((bal["1100"], bal["5900"]), (D("0.00"), D("5000.00")))
        self.assertEqual(dr, cr)

    def test_payment_currency_must_match_document(self):
        doc = services.issue_document(self.invoice(), self.fin)
        with self.assertRaises(ValidationError):
            services.record_payment(
                entity=self.entity, user=self.fin, kind="received", contact=doc.contact, date=date(2026, 11, 5),
                currency=self.usd, bank_account=self.acct["1010"], allocations=[(doc, D("10"))], fx_rate=D("1750"),
            )


class Voiding(Base):
    def test_void_paid_document_needs_payment_voided_first(self):
        doc = services.issue_document(self.invoice(), self.fin)
        pay = self.pay(doc, "100")
        with self.assertRaises(ValidationError):
            services.void_document(doc, self.fin)
        services.void_payment(pay, self.fin)
        self.assertEqual(Document.objects.get(pk=doc.pk).balance, D("1165.00"))
        services.void_document(doc, self.fin)
        self.assertEqual(Document.objects.get(pk=doc.pk).status, "void")
        bal, dr, cr = self.balances()
        self.assertTrue(all(v == 0 for v in bal.values()), bal)
        with self.assertRaises(ValidationError):
            services.void_payment(pay, self.fin)

    def test_delete_draft_only(self):
        draft = self.invoice()
        services.delete_draft(draft, self.fin)
        self.assertFalse(Document.objects.filter(pk=draft.pk).exists())
        issued = services.issue_document(self.invoice(), self.fin)
        with self.assertRaises(ValidationError):
            services.delete_draft(issued, self.fin)


class AgingReport(Base):
    def test_buckets(self):
        today = timezone.localdate()
        specs = [(today + timedelta(days=5), "100"), (today - timedelta(days=10), "200"), (today - timedelta(days=45), "300"),
                 (today - timedelta(days=75), "400"), (today - timedelta(days=200), "500")]
        for due, price in specs:
            doc = self.invoice(price, when=due - timedelta(days=30), due_date=due, tax=False)
            services.issue_document(doc, self.fin)
        rows, totals, grand = services.aging(self.entity, "invoice", today)
        self.assertEqual(len(rows), 1)
        self.assertEqual(totals, [D("100.00"), D("200.00"), D("300.00"), D("400.00"), D("500.00")])
        self.assertEqual(grand, D("1500.00"))

    def test_paid_documents_excluded(self):
        doc = services.issue_document(self.invoice("100", tax=False), self.fin)
        self.pay(doc, "100")
        self.assertEqual(services.aging(self.entity, "invoice")[2], D("0.00"))


class Screens(Base):
    def setUp(self):
        self.client.login(username="fin", password="pw")

    def test_pages_render(self):
        doc = services.issue_document(self.invoice(), self.fin)
        for name in ("invoice_list", "bill_list", "invoice_new", "bill_new", "contact_list", "contact_new", "aging_report"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)
        page = self.client.get(reverse("document_detail", args=[doc.pk]))
        self.assertContains(page, "Record payment received")
        self.assertContains(self.client.get(reverse("aging_report") + "?kind=bill"), "Payables aging")

    def test_create_issue_and_pay_through_forms(self):
        data = {
            "contact": self.customer.pk, "date": "2026-11-01", "due_date": "", "currency": "MWK", "reference": "PO-9", "notes": "",
            "form-TOTAL_FORMS": "4", "form-INITIAL_FORMS": "0", "form-MIN_NUM_FORMS": "0", "form-MAX_NUM_FORMS": "1000",
            "form-0-description": "Pilot fee", "form-0-account": self.acct["4010"].pk, "form-0-quantity": "2",
            "form-0-unit_price": "500", "form-0-tax_rate": self.vat.pk, "issue": "1",
        }
        resp = self.client.post(reverse("invoice_new"), data)
        self.assertEqual(resp.status_code, 302)
        doc = Document.objects.get(reference="PO-9")
        self.assertEqual((doc.status, doc.total, doc.due_date), ("issued", D("1165.00"), date(2026, 12, 1)))
        resp = self.client.post(reverse("document_pay", args=[doc.pk]), {
            "date": "2026-11-05", "amount": "1165.00", "bank_account": self.acct["1010"].pk, "reference": "EFT1"})
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(Document.objects.get(pk=doc.pk).is_paid)
        self.assertContains(self.client.get(reverse("document_detail", args=[doc.pk])), "Paid")

    def test_incomplete_line_is_rejected(self):
        data = {
            "contact": self.customer.pk, "date": "2026-11-01", "currency": "MWK",
            "form-TOTAL_FORMS": "4", "form-INITIAL_FORMS": "0", "form-MIN_NUM_FORMS": "0", "form-MAX_NUM_FORMS": "1000",
            "form-0-description": "No account or price",
        }
        resp = self.client.post(reverse("invoice_new"), data)
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Each line needs")
        self.assertFalse(Document.objects.exists())

    def test_other_entity_document_is_hidden(self):
        other = Entity.objects.create(name="808 Kenya", country="KE", base_currency=Currency.objects.get(code="KES"))
        user = User.objects.create_user("ken", password="pw")
        Membership.objects.create(user=user, entity=other, role="admin")
        doc = services.issue_document(self.invoice(), self.fin)
        self.client.logout()
        self.client.login(username="ken", password="pw")
        self.assertEqual(self.client.get(reverse("document_detail", args=[doc.pk])).status_code, 404)

    def test_viewer_can_read_but_not_create(self):
        self.client.logout()
        self.client.login(username="view", password="pw")
        self.assertEqual(self.client.get(reverse("invoice_list")).status_code, 200)
        self.assertEqual(self.client.get(reverse("invoice_new")).status_code, 403)

    def test_missing_billing_settings_is_friendly(self):
        BillingSettings.objects.all().delete()
        resp = self.client.get(reverse("invoice_new"), follow=True)
        self.assertContains(resp, "seed_billing")


class OwnedJournals(Base):
    def test_document_journals_cannot_be_reversed_directly(self):
        doc = services.issue_document(self.invoice(), self.fin)
        with self.assertRaises(ValidationError):
            ledger.reverse_journal(doc.journal, self.fin)
        pay = self.pay(doc, "100")
        with self.assertRaises(ValidationError):
            ledger.reverse_journal(pay.journal, self.fin)
        # voiding through the owner still works
        services.void_payment(pay, self.fin)
        services.void_document(doc, self.fin)

    def test_screen_hides_reverse_button_for_owned_journal(self):
        doc = services.issue_document(self.invoice(), self.fin)
        self.client.login(username="fin", password="pw")
        page = self.client.get(reverse("journal_detail", args=[doc.journal.pk]))
        self.assertNotContains(page, "Reverse this journal")
        self.assertContains(page, "void the invoice")
        resp = self.client.post(reverse("journal_action", args=[doc.journal.pk, "reverse"]), follow=True)
        self.assertContains(resp, "Void the invoice")
        self.assertFalse(Journal.objects.filter(reversal_of=doc.journal).exists())
