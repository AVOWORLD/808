from decimal import Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Sum
from django.utils import timezone

from core.models import Currency, Entity
from ledger.models import ZERO, Account, Journal, money


class BillingSettings(models.Model):
    """Which ledger accounts invoices, bills and payments post to, per entity.

    Kept as settings (not hard-coded codes) so the accountant's chart can replace
    the starter one without changing any code.
    """

    entity = models.OneToOneField(Entity, on_delete=models.CASCADE, related_name="billing_settings")
    receivable = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+", verbose_name="Accounts receivable")
    payable = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+", verbose_name="Accounts payable")
    vat_output = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+", verbose_name="VAT output (sales tax payable)")
    vat_input = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+", verbose_name="VAT input (purchase tax receivable)")
    fx_gain = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+", verbose_name="FX gain / rounding gain")
    fx_loss = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+", verbose_name="FX loss / rounding loss")
    payment_terms_days = models.PositiveSmallIntegerField(default=30)

    class Meta:
        verbose_name_plural = "billing settings"

    def __str__(self):
        return f"Billing settings for {self.entity.name}"

    def clean(self):
        for name in ("receivable", "payable", "vat_output", "vat_input", "fx_gain", "fx_loss"):
            acct = getattr(self, name, None)
            if acct is not None and acct.entity_id != self.entity_id:
                raise ValidationError(f"{name} must be an account of {self.entity.name}.")


class TaxRate(models.Model):
    entity = models.ForeignKey(Entity, on_delete=models.CASCADE, related_name="tax_rates")
    name = models.CharField(max_length=60)
    rate = models.DecimalField(max_digits=5, decimal_places=2, help_text="Percent, e.g. 16.50")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]
        constraints = [models.UniqueConstraint(fields=["entity", "name"], name="uniq_taxrate_name_per_entity")]

    def __str__(self):
        return f"{self.name} ({self.rate}%)"


class Contact(models.Model):
    CUSTOMER, SUPPLIER, BOTH = "customer", "supplier", "both"
    KINDS = [(CUSTOMER, "Customer"), (SUPPLIER, "Supplier"), (BOTH, "Customer and supplier")]

    entity = models.ForeignKey(Entity, on_delete=models.CASCADE, related_name="contacts")
    name = models.CharField(max_length=120)
    kind = models.CharField(max_length=10, choices=KINDS, default=CUSTOMER)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=40, blank=True)
    tax_number = models.CharField(max_length=40, blank=True, help_text="Tax or VAT registration number, if any.")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]
        constraints = [models.UniqueConstraint(fields=["entity", "name"], name="uniq_contact_name_per_entity")]

    def __str__(self):
        return self.name


class Document(models.Model):
    """A sales invoice (money owed to us) or a supplier bill (money we owe)."""

    INVOICE, BILL = "invoice", "bill"
    KINDS = [(INVOICE, "Invoice"), (BILL, "Bill")]
    DRAFT, ISSUED, VOID = "draft", "issued", "void"
    STATUSES = [(DRAFT, "Draft"), (ISSUED, "Issued"), (VOID, "Void")]

    entity = models.ForeignKey(Entity, on_delete=models.PROTECT, related_name="documents")
    kind = models.CharField(max_length=10, choices=KINDS)
    contact = models.ForeignKey(Contact, on_delete=models.PROTECT, related_name="documents")
    number = models.PositiveIntegerField(null=True, blank=True, help_text="Assigned when issued.")
    date = models.DateField()
    due_date = models.DateField()
    currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="+")
    fx_rate = models.DecimalField(max_digits=18, decimal_places=6, default=Decimal("1"), help_text="Fixed when issued.")
    reference = models.CharField(max_length=60, blank=True)
    notes = models.TextField(blank=True)
    status = models.CharField(max_length=10, choices=STATUSES, default=DRAFT)
    journal = models.OneToOneField(Journal, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    issued_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    issued_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-date", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["entity", "kind", "number"],
                condition=models.Q(number__isnull=False),
                name="uniq_document_number_per_entity_kind",
            )
        ]

    @property
    def prefix(self):
        return "INV" if self.kind == self.INVOICE else "BILL"

    def __str__(self):
        if self.number:
            return f"{self.prefix}-{self.number:04d}"
        return f"Draft {self.get_kind_display().lower()} #{self.pk}"

    def _sum(self, field):
        return sum((getattr(line, field) for line in self.lines.all()), ZERO)

    @property
    def subtotal(self):
        return self._sum("net")

    @property
    def tax_total(self):
        return self._sum("tax")

    @property
    def total(self):
        return self.subtotal + self.tax_total

    @property
    def amount_paid(self):
        row = PaymentAllocation.objects.filter(document=self, payment__status=Payment.POSTED).aggregate(s=Sum("amount"))
        return row["s"] or ZERO

    @property
    def balance(self):
        return self.total - self.amount_paid

    @property
    def is_paid(self):
        return self.status == self.ISSUED and self.balance <= 0

    @property
    def is_overdue(self):
        return self.status == self.ISSUED and self.balance > 0 and self.due_date < timezone.localdate()

    @property
    def display_status(self):
        if self.status != self.ISSUED:
            return self.status
        if self.is_paid:
            return "paid"
        return "overdue" if self.is_overdue else "open"


class DocumentLine(models.Model):
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="lines")
    description = models.CharField(max_length=255)
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+")
    quantity = models.DecimalField(max_digits=12, decimal_places=3, default=Decimal("1"))
    unit_price = models.DecimalField(max_digits=18, decimal_places=2)
    tax_rate = models.ForeignKey(TaxRate, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    net = models.DecimalField(max_digits=18, decimal_places=2, default=ZERO, editable=False)
    tax = models.DecimalField(max_digits=18, decimal_places=2, default=ZERO, editable=False)

    class Meta:
        ordering = ["id"]

    def _document_status(self):
        return Document.objects.filter(pk=self.document_id).values_list("status", flat=True).first()

    def save(self, *args, **kwargs):
        if self._document_status() not in (None, Document.DRAFT):
            raise ValidationError("Lines of an issued document cannot be changed.")
        self.net = money(self.quantity * self.unit_price)
        self.tax = money(self.net * self.tax_rate.rate / Decimal("100")) if self.tax_rate_id else ZERO
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self._document_status() not in (None, Document.DRAFT):
            raise ValidationError("Lines of an issued document cannot be deleted.")
        return super().delete(*args, **kwargs)


class Payment(models.Model):
    RECEIVED, PAID = "received", "paid"
    KINDS = [(RECEIVED, "Received from customer"), (PAID, "Paid to supplier")]
    POSTED, VOID = "posted", "void"

    entity = models.ForeignKey(Entity, on_delete=models.PROTECT, related_name="payments")
    kind = models.CharField(max_length=10, choices=KINDS)
    contact = models.ForeignKey(Contact, on_delete=models.PROTECT, related_name="payments")
    date = models.DateField()
    currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="+")
    amount = models.DecimalField(max_digits=18, decimal_places=2)
    fx_rate = models.DecimalField(max_digits=18, decimal_places=6, default=Decimal("1"))
    bank_account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="+")
    reference = models.CharField(max_length=60, blank=True)
    status = models.CharField(max_length=10, default=POSTED, choices=[(POSTED, "Posted"), (VOID, "Void")])
    journal = models.OneToOneField(Journal, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date", "-id"]

    def __str__(self):
        return f"Payment #{self.pk} {self.amount} {self.currency_id}"


class PaymentAllocation(models.Model):
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE, related_name="allocations")
    document = models.ForeignKey(Document, on_delete=models.PROTECT, related_name="allocations")
    amount = models.DecimalField(max_digits=18, decimal_places=2)
