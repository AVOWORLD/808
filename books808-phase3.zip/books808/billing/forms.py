from datetime import timedelta
from decimal import Decimal

from django import forms
from django.forms import formset_factory
from django.utils import timezone

from core.models import Currency
from ledger.models import Account

from .models import Contact, Document, TaxRate

DATE = lambda: forms.DateInput(attrs={"type": "date"})


class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ["name", "kind", "email", "phone", "tax_number"]


class DocumentForm(forms.Form):
    contact = forms.ModelChoiceField(queryset=Contact.objects.none())
    date = forms.DateField(widget=DATE(), initial=timezone.localdate)
    due_date = forms.DateField(widget=DATE(), required=False, help_text="Leave blank to use the payment terms.")
    currency = forms.ModelChoiceField(queryset=Currency.objects.all())
    reference = forms.CharField(max_length=60, required=False)
    notes = forms.CharField(widget=forms.Textarea(attrs={"rows": 2}), required=False)

    def __init__(self, *args, entity, kind, terms_days=30, **kwargs):
        super().__init__(*args, **kwargs)
        self.terms_days = terms_days
        wanted = Contact.CUSTOMER if kind == Document.INVOICE else Contact.SUPPLIER
        self.fields["contact"].queryset = Contact.objects.filter(
            entity=entity, is_active=True, kind__in=[wanted, Contact.BOTH]
        )
        self.fields["currency"].initial = entity.base_currency_id

    def clean(self):
        data = super().clean()
        if data.get("date") and not data.get("due_date"):
            data["due_date"] = data["date"] + timedelta(days=self.terms_days)
        return data


class DocLineForm(forms.Form):
    description = forms.CharField(max_length=255, required=False)
    account = forms.ModelChoiceField(queryset=Account.objects.none(), required=False)
    quantity = forms.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal("0.001"), required=False, initial=1)
    unit_price = forms.DecimalField(max_digits=18, decimal_places=2, min_value=0, required=False)
    tax_rate = forms.ModelChoiceField(queryset=TaxRate.objects.none(), required=False, empty_label="No tax")

    def __init__(self, *args, entity=None, kind=Document.INVOICE, **kwargs):
        super().__init__(*args, **kwargs)
        types = [Account.INCOME] if kind == Document.INVOICE else [Account.EXPENSE, Account.ASSET]
        self.fields["account"].queryset = Account.objects.filter(
            entity=entity, is_active=True, is_postable=True, type__in=types
        )
        self.fields["tax_rate"].queryset = TaxRate.objects.filter(entity=entity, is_active=True)

    def clean(self):
        data = super().clean()
        if data.get("description") or data.get("unit_price") is not None:
            for name, label in (("description", "a description"), ("account", "an account"), ("unit_price", "a price")):
                if data.get(name) in (None, ""):
                    raise forms.ValidationError(f"Each line needs {label}.")
            if data.get("quantity") is None:
                data["quantity"] = Decimal("1")
            data["used"] = True
        return data


DocLineFormSet = formset_factory(DocLineForm, extra=4)


class PaymentForm(forms.Form):
    date = forms.DateField(widget=DATE(), initial=timezone.localdate)
    amount = forms.DecimalField(max_digits=18, decimal_places=2, min_value=Decimal("0.01"))
    bank_account = forms.ModelChoiceField(queryset=Account.objects.none(), label="Bank or cash account")
    fx_rate = forms.DecimalField(
        max_digits=18, decimal_places=6, min_value=Decimal("0.000001"), required=False, label="Exchange rate",
        help_text="Only for foreign currency. Blank uses the latest stored rate.",
    )
    reference = forms.CharField(max_length=60, required=False)

    def __init__(self, *args, entity, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["bank_account"].queryset = Account.objects.filter(
            entity=entity, type=Account.ASSET, is_active=True, is_postable=True
        )
