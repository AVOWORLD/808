"""Create clearly labelled DEMO customers, suppliers, invoices, a bill and a part-payment.

Invented MWK numbers dated relative to today so the aging report shows several buckets.
Development databases only.
"""

from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone

from billing import services
from billing.models import Contact, Payment, TaxRate
from core.models import Currency, Entity
from ledger.models import Account


class Command(BaseCommand):
    help = "Create DEMO billing data for the Malawi entity (development only)."

    def add_arguments(self, parser):
        parser.add_argument("--username", required=True, help="A finance or admin user in the Malawi entity.")

    def handle(self, *args, **opts):
        user = get_user_model().objects.filter(username=opts["username"]).first()
        entity = Entity.objects.filter(name="808 Computing Malawi").first()
        if user is None or entity is None:
            raise CommandError("Run seed_malawi first and pass an existing --username.")
        if Contact.objects.filter(entity=entity, name__startswith="DEMO").exists():
            self.stdout.write("Demo billing data already exists; nothing to do.")
            return
        today = timezone.localdate()
        mwk = Currency.objects.get(code="MWK")
        acct = {a.code: a for a in Account.objects.filter(entity=entity)}
        vat = TaxRate.objects.get(entity=entity, name__startswith="VAT standard")
        mine = Contact.objects.create(entity=entity, name="DEMO Sample Mining Ltd", kind="customer")
        chamber = Contact.objects.create(entity=entity, name="DEMO Chamber of Mines", kind="customer")
        host = Contact.objects.create(entity=entity, name="DEMO Cloud Host Africa", kind="supplier")

        def invoice(contact, days_ago, terms, desc, account, price):
            when = today - timedelta(days=days_ago)
            doc = services.create_document(
                entity=entity, user=user, kind="invoice", contact=contact, date=when, due_date=when + timedelta(days=terms),
                currency=mwk, reference="DEMO",
                lines=[{"description": desc, "account": acct[account], "quantity": 1, "unit_price": price, "tax_rate": vat}],
            )
            return services.issue_document(doc, user)

        first = invoice(mine, 70, 30, "Stockpile survey pilot", "4010", 3_000_000)
        invoice(mine, 10, 30, "Monthly Strata subscription", "4020", 450_000)
        invoice(chamber, 50, 30, "Royalty tracking pilot", "4010", 1_800_000)
        when = today - timedelta(days=20)
        bill = services.create_document(
            entity=entity, user=user, kind="bill", contact=host, date=when, due_date=when + timedelta(days=30), currency=mwk,
            reference="DEMO",
            lines=[{"description": "Cloud hosting", "account": acct["5010"], "quantity": 1, "unit_price": 600_000, "tax_rate": vat}],
        )
        services.issue_document(bill, user)
        services.record_payment(
            entity=entity, user=user, kind=Payment.RECEIVED, contact=mine, date=today - timedelta(days=40), currency=mwk,
            bank_account=acct["1010"], allocations=[(first, 1_000_000)], reference="DEMO EFT",
        )
        self.stdout.write(self.style.SUCCESS("Created 3 demo contacts, 3 invoices, 1 bill and 1 part-payment."))
