"""Link billing to each entity's chart of accounts and add starter tax rates.

Safe to run repeatedly. The accounts and the VAT rate are PLACEHOLDERS from the starter chart:
the accountant should confirm them (Billing settings and Tax rates in the admin).
"""

from django.core.management.base import BaseCommand

from billing.models import BillingSettings, TaxRate
from core.models import Entity
from ledger.models import Account

CODES = {
    "receivable": "1100",
    "payable": "2010",
    "vat_output": "2100",
    "vat_input": "1300",
    "fx_gain": "4900",
    "fx_loss": "5900",
}
TAX_RATES = [("VAT standard (placeholder rate - confirm)", "16.50"), ("Zero rated", "0.00"), ("Exempt", "0.00")]


class Command(BaseCommand):
    help = "Create billing settings and starter tax rates for entities using the starter chart."

    def handle(self, *args, **opts):
        done = 0
        for entity in Entity.objects.all():
            accounts = {a.code: a for a in Account.objects.filter(entity=entity, code__in=CODES.values())}
            if len(accounts) < len(CODES):
                self.stdout.write(f"Skipped {entity.name}: starter accounts {sorted(CODES.values())} not all present.")
                continue
            BillingSettings.objects.get_or_create(
                entity=entity, defaults={field: accounts[code] for field, code in CODES.items()}
            )
            for name, rate in TAX_RATES:
                TaxRate.objects.get_or_create(entity=entity, name=name, defaults={"rate": rate})
            done += 1
        self.stdout.write(self.style.SUCCESS(f"Billing set up for {done} entity(ies)."))
