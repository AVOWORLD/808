from django.contrib import admin

from .models import BillingSettings, Contact, Document, Payment, TaxRate

admin.site.register(BillingSettings)
admin.site.register(TaxRate)
admin.site.register(Contact)


class ReadOnly(admin.ModelAdmin):
    """Documents and payments change only through the app, which keeps the ledger consistent."""

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Document)
class DocumentAdmin(ReadOnly):
    list_display = ("__str__", "entity", "contact", "date", "status")
    list_filter = ("entity", "kind", "status")


@admin.register(Payment)
class PaymentAdmin(ReadOnly):
    list_display = ("__str__", "entity", "contact", "date", "status")
    list_filter = ("entity", "kind", "status")
