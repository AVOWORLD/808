"""Business rules for invoices, bills and payments.

Everything that touches money goes through ledger.services (create_draft, post_journal,
reverse_journal), so these documents inherit balancing, roles, immutability and the
audit log. Views call these functions and nothing else writes billing records.
"""

from decimal import Decimal

from django.core.exceptions import ObjectDoesNotExist, PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Max
from django.utils import timezone

from core.models import Entity
from ledger import services as ledger
from ledger.models import ZERO, Account, money

from .models import Contact, Document, DocumentLine, Payment, PaymentAllocation

ONE = Decimal("1")


def get_settings(entity):
    try:
        return entity.billing_settings
    except ObjectDoesNotExist:
        raise ValidationError(
            "Billing accounts aren't set up for this entity. Run `python manage.py seed_billing` "
            "or add Billing settings in the admin."
        )


def _line_accounts_ok(kind, account):
    allowed = (Account.INCOME,) if kind == Document.INVOICE else (Account.EXPENSE, Account.ASSET)
    return account.type in allowed


@transaction.atomic
def create_document(*, entity, user, kind, contact, date, due_date, currency, lines, reference="", notes=""):
    """lines: dicts with description, account, quantity, unit_price, tax_rate (TaxRate or None)."""
    ledger.require_submit(user, entity)
    get_settings(entity)
    if contact.entity_id != entity.pk:
        raise ValidationError("That contact belongs to a different entity.")
    wanted = Contact.CUSTOMER if kind == Document.INVOICE else Contact.SUPPLIER
    if contact.kind not in (wanted, Contact.BOTH):
        raise ValidationError(f"{contact.name} is not set up as a {wanted}.")
    if not lines:
        raise ValidationError("Add at least one line.")
    if due_date < date:
        raise ValidationError("The due date can't be before the document date.")
    doc = Document.objects.create(
        entity=entity, kind=kind, contact=contact, date=date, due_date=due_date, currency=currency,
        reference=reference, notes=notes, created_by=user,
    )
    for row in lines:
        account, tax_rate = row["account"], row.get("tax_rate")
        if account.entity_id != entity.pk or (tax_rate is not None and tax_rate.entity_id != entity.pk):
            raise ValidationError("Accounts and tax rates must belong to this entity.")
        if not account.is_active or not account.is_postable:
            raise ValidationError(f"Account {account.code} can't be used.")
        if not _line_accounts_ok(kind, account):
            raise ValidationError(f"Account {account.code} {account.name} is not valid for a {kind} line.")
        if row["quantity"] <= 0 or row["unit_price"] < 0:
            raise ValidationError("Quantity must be above zero and the price can't be negative.")
        DocumentLine.objects.create(
            document=doc, description=row["description"], account=account, quantity=row["quantity"],
            unit_price=row["unit_price"], tax_rate=tax_rate,
        )
    ledger.log(entity, user, "create_document", doc, f"{doc.get_kind_display()} for {contact.name}")
    return doc


def _fx_balance(entity, settings, lines):
    """Add one base-currency line that absorbs rounding or exchange differences so the journal balances."""
    dr = sum((money(Decimal(l.get("debit") or 0) * l["fx_rate"]) for l in lines), ZERO)
    cr = sum((money(Decimal(l.get("credit") or 0) * l["fx_rate"]) for l in lines), ZERO)
    diff = dr - cr
    base = entity.base_currency
    if diff > 0:
        lines.append({"account": settings.fx_gain, "currency": base, "credit": diff, "fx_rate": ONE,
                      "description": "Exchange difference / rounding"})
    elif diff < 0:
        lines.append({"account": settings.fx_loss, "currency": base, "debit": -diff, "fx_rate": ONE,
                      "description": "Exchange difference / rounding"})


@transaction.atomic
def issue_document(doc, user):
    ledger.require_post(user, doc.entity)
    entity = Entity.objects.select_for_update().get(pk=doc.entity_id)
    doc = Document.objects.select_for_update().get(pk=doc.pk)
    if doc.status != Document.DRAFT:
        raise ValidationError("Only draft documents can be issued.")
    cfg = get_settings(entity)
    lines = list(doc.lines.select_related("account"))
    if not lines or doc.total <= 0:
        raise ValidationError("A document needs at least one line and a total above zero.")
    if not doc.contact.is_active:
        raise ValidationError(f"{doc.contact.name} is inactive.")

    rate = ledger.resolve_rate(entity, doc.currency, doc.date)
    cur = doc.currency
    by_account = {}
    for l in lines:
        acct, total = by_account.get(l.account_id, (l.account, ZERO))
        by_account[l.account_id] = (acct, total + l.net)

    def row(account, debit=None, credit=None, description=""):
        return {"account": account, "currency": cur, "fx_rate": rate, "debit": debit, "credit": credit, "description": description}

    jl = []
    if doc.kind == Document.INVOICE:
        jl.append(row(cfg.receivable, debit=doc.total, description=f"Receivable {doc.contact.name}"))
        jl += [row(a, credit=t) for a, t in by_account.values() if t]
        if doc.tax_total:
            jl.append(row(cfg.vat_output, credit=doc.tax_total, description="Output VAT"))
    else:
        jl += [row(a, debit=t) for a, t in by_account.values() if t]
        if doc.tax_total:
            jl.append(row(cfg.vat_input, debit=doc.tax_total, description="Input VAT"))
        jl.append(row(cfg.payable, credit=doc.total, description=f"Payable {doc.contact.name}"))
    _fx_balance(entity, cfg, jl)

    last = Document.objects.filter(entity=entity, kind=doc.kind).aggregate(m=Max("number"))["m"] or 0
    doc.number = last + 1
    doc.fx_rate = rate
    memo = f"{doc} {doc.contact.name}"
    journal = ledger.create_draft(
        entity=entity, user=user, date=doc.date, memo=memo, lines=jl, reference=doc.reference or str(doc),
        source=doc.kind,
    )
    ledger.post_journal(journal, user)
    doc.journal_id = journal.pk
    doc.status = Document.ISSUED
    doc.issued_by, doc.issued_at = user, timezone.now()
    doc.save()
    ledger.log(entity, user, "issue_document", doc, f"{doc} total {doc.total} {cur.pk}")
    return doc


@transaction.atomic
def record_payment(*, entity, user, kind, contact, date, currency, bank_account, allocations, reference="", fx_rate=None):
    """allocations: list of (Document, amount). The payment equals the sum of its allocations."""
    ledger.require_post(user, entity)
    cfg = get_settings(entity)
    if not allocations:
        raise ValidationError("Choose at least one document to pay.")
    expected_doc = Document.INVOICE if kind == Payment.RECEIVED else Document.BILL
    if bank_account.entity_id != entity.pk or bank_account.type != Account.ASSET or not bank_account.is_postable or not bank_account.is_active:
        raise ValidationError("Choose an active bank or cash account of this entity.")
    total = ZERO
    seen = set()
    for doc, amount in allocations:
        doc = Document.objects.select_for_update().get(pk=doc.pk)
        if doc.pk in seen:
            raise ValidationError("A document can only appear once in a payment.")
        seen.add(doc.pk)
        if doc.entity_id != entity.pk or doc.kind != expected_doc or doc.contact_id != contact.pk:
            raise ValidationError(f"{doc} doesn't match this payment.")
        if doc.status != Document.ISSUED:
            raise ValidationError(f"{doc} is not issued, so it can't be paid.")
        if doc.currency_id != currency.pk:
            raise ValidationError(f"{doc} is in {doc.currency_id}; the payment must be in the same currency.")
        if amount <= 0:
            raise ValidationError("Payment amounts must be above zero.")
        if amount > doc.balance:
            raise ValidationError(f"{doc} has only {doc.balance} outstanding; you entered {amount}.")
        total += amount

    pay_rate = fx_rate or ledger.resolve_rate(entity, currency, date)
    fixed = [(Document.objects.get(pk=d.pk), a) for d, a in allocations]

    def row(account, rate, debit=None, credit=None, description=""):
        return {"account": account, "currency": currency, "fx_rate": rate, "debit": debit, "credit": credit, "description": description}

    jl = []
    if kind == Payment.RECEIVED:
        jl.append(row(bank_account, pay_rate, debit=total, description=f"Received from {contact.name}"))
        jl += [row(cfg.receivable, d.fx_rate, credit=a, description=f"Applied to {d}") for d, a in fixed]
    else:
        jl += [row(cfg.payable, d.fx_rate, debit=a, description=f"Applied to {d}") for d, a in fixed]
        jl.append(row(bank_account, pay_rate, credit=total, description=f"Paid to {contact.name}"))
    _fx_balance(entity, cfg, jl)

    payment = Payment.objects.create(
        entity=entity, kind=kind, contact=contact, date=date, currency=currency, amount=total, fx_rate=pay_rate,
        bank_account=bank_account, reference=reference, created_by=user,
    )
    names = ", ".join(str(d) for d, _ in fixed)
    journal = ledger.create_draft(
        entity=entity, user=user, date=date, memo=f"Payment {payment.get_kind_display().lower()} {contact.name}: {names}",
        lines=jl, reference=reference or f"PAY-{payment.pk}", source="payment",
    )
    ledger.post_journal(journal, user)
    payment.journal_id = journal.pk
    payment.save()
    for d, a in fixed:
        PaymentAllocation.objects.create(payment=payment, document=d, amount=a)
    ledger.log(entity, user, "record_payment", payment, f"{total} {currency.pk} against {names}")
    return payment


@transaction.atomic
def void_payment(payment, user):
    ledger.require_post(user, payment.entity)
    payment = Payment.objects.select_for_update().get(pk=payment.pk)
    if payment.status != Payment.POSTED:
        raise ValidationError("This payment is already void.")
    ledger.reverse_journal(payment.journal, user, system=True)
    payment.status = Payment.VOID
    payment.save()
    ledger.log(payment.entity, user, "void_payment", payment, "reversed")
    return payment


@transaction.atomic
def void_document(doc, user):
    ledger.require_post(user, doc.entity)
    doc = Document.objects.select_for_update().get(pk=doc.pk)
    if doc.status != Document.ISSUED:
        raise ValidationError("Only issued documents can be voided. Delete a draft instead.")
    if doc.amount_paid > 0:
        raise ValidationError("This document has payments against it. Void the payments first.")
    ledger.reverse_journal(doc.journal, user, system=True)
    doc.status = Document.VOID
    doc.save()
    ledger.log(doc.entity, user, "void_document", doc, "reversed")
    return doc


@transaction.atomic
def delete_draft(doc, user):
    doc = Document.objects.select_for_update().get(pk=doc.pk)
    m = ledger.membership_for(user, doc.entity)
    if not m or not (m.can_post or (m.can_submit and doc.created_by_id == user.pk)):
        raise PermissionDenied("You can't delete this draft.")
    if doc.status != Document.DRAFT:
        raise ValidationError("Only drafts can be deleted.")
    ledger.log(doc.entity, user, "delete_draft_document", doc, str(doc))
    doc.delete()


BUCKET_NAMES = ["Not yet due", "1-30 days", "31-60 days", "61-90 days", "Over 90 days"]


def aging(entity, kind, today=None):
    """Outstanding balances by contact and days past due, in the entity's base currency.

    Uses each document's own issue-date rate, so foreign balances are not revalued."""
    today = today or timezone.localdate()
    docs = (
        Document.objects.filter(entity=entity, kind=kind, status=Document.ISSUED)
        .select_related("contact", "currency")
        .prefetch_related("lines")
    )
    rows = {}
    for d in docs:
        bal = d.balance
        if bal <= 0:
            continue
        days = (today - d.due_date).days
        idx = 0 if days <= 0 else 1 if days <= 30 else 2 if days <= 60 else 3 if days <= 90 else 4
        base = money(bal * d.fx_rate)
        r = rows.setdefault(d.contact_id, {"contact": d.contact, "buckets": [ZERO] * 5, "total": ZERO})
        r["buckets"][idx] += base
        r["total"] += base
    ordered = sorted(rows.values(), key=lambda r: r["contact"].name.lower())
    totals = [sum((r["buckets"][i] for r in ordered), ZERO) for i in range(5)]
    return ordered, totals, sum(totals, ZERO)
