from django.urls import path

from . import views

urlpatterns = [
    path("invoices/", views.invoice_list, name="invoice_list"),
    path("invoices/new/", views.invoice_new, name="invoice_new"),
    path("bills/", views.bill_list, name="bill_list"),
    path("bills/new/", views.bill_new, name="bill_new"),
    path("documents/<int:pk>/", views.document_detail, name="document_detail"),
    path("documents/<int:pk>/pay/", views.document_pay, name="document_pay"),
    path("documents/<int:pk>/<str:action>/", views.document_action, name="document_action"),
    path("payments/<int:pk>/void/", views.payment_void, name="payment_void"),
    path("contacts/", views.contact_list, name="contact_list"),
    path("contacts/new/", views.contact_new, name="contact_new"),
    path("reports/aging/", views.aging_report, name="aging_report"),
]
