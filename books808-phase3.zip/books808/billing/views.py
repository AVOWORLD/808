from django.contrib import messages
from django.core.exceptions import PermissionDenied, ValidationError
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from ledger.views import entity_required

from . import services
from .forms import ContactForm, DocLineFormSet, DocumentForm, PaymentForm
from .models import Contact, Document, Payment


def _msgs(exc):
    return " ".join(exc.messages) if isinstance(exc, ValidationError) else (str(exc) or "Not allowed.")


KIND_PAGES = {
    Document.INVOICE: {"title": "Invoices", "singular": "invoice", "who": "Customer", "list": "invoice_list", "new": "invoice_new"},
    Document.BILL: {"title": "Bills", "singular": "bill", "who": "Supplier", "list": "bill_list", "new": "bill_new"},
}


def _document_list(request, kind):
    entity = request.membership.entity
    status = request.GET.get("status")
    docs = Document.objects.filter(entity=entity, kind=kind).select_related("contact", "currency").prefetch_related("lines")
    if status in (Document.DRAFT, Document.ISSUED, Document.VOID):
        docs = docs.filter(status=status)
    return render(request, "billing/document_list.html", {"docs": docs[:200], "kind": kind, "page": KIND_PAGES[kind], "status": status})


@entity_required
def invoice_list(request):
    return _document_list(request, Document.INVOICE)


@entity_required
def bill_list(request):
    return _document_list(request, Document.BILL)


def _document_new(request, kind):
    membership = request.membership
    entity = membership.entity
    if not membership.can_submit:
        raise PermissionDenied
    try:
        cfg = services.get_settings(entity)
    except ValidationError as exc:
        messages.error(request, _msgs(exc))
        return redirect("dashboard")
    kw = {"entity": entity, "kind": kind}
    form = DocumentForm(request.POST or None, terms_days=cfg.payment_terms_days, **kw)
    formset = DocLineFormSet(request.POST or None, form_kwargs=kw)
    if request.method == "POST" and form.is_valid() and formset.is_valid():
        lines = [f.cleaned_data for f in formset if f.cleaned_data.get("used")]
        try:
            doc = services.create_document(
                entity=entity, user=request.user, kind=kind, lines=lines,
                contact=form.cleaned_data["contact"], date=form.cleaned_data["date"], due_date=form.cleaned_data["due_date"],
                currency=form.cleaned_data["currency"], reference=form.cleaned_data["reference"], notes=form.cleaned_data["notes"],
            )
        except (ValidationError, PermissionDenied) as exc:
            form.add_error(None, _msgs(exc))
        else:
            if "issue" in request.POST and membership.can_post:
                try:
                    services.issue_document(doc, request.user)
                    messages.success(request, f"{doc} issued.")
                except ValidationError as exc:
                    messages.error(request, _msgs(exc) + " Saved as a draft.")
            else:
                messages.success(request, "Draft saved.")
            return redirect("document_detail", pk=doc.pk)
    return render(request, "billing/document_form.html", {"form": form, "formset": formset, "kind": kind, "page": KIND_PAGES[kind], "can_post": membership.can_post})


@entity_required
def invoice_new(request):
    return _document_new(request, Document.INVOICE)


@entity_required
def bill_new(request):
    return _document_new(request, Document.BILL)


@entity_required
def document_detail(request, pk):
    entity = request.membership.entity
    doc = get_object_or_404(Document.objects.select_related("contact", "currency", "created_by", "issued_by", "journal"), pk=pk, entity=entity)
    payments = [a for a in doc.allocations.select_related("payment", "payment__bank_account").order_by("-payment__date", "-id")]
    balance = doc.balance
    pay_form = None
    if doc.status == Document.ISSUED and balance > 0 and request.membership.can_post:
        pay_form = PaymentForm(initial={"amount": balance}, entity=entity)
    return render(
        request,
        "billing/document_detail.html",
        {
            "doc": doc, "lines": doc.lines.select_related("account", "tax_rate"), "payments": payments, "pay_form": pay_form,
            "page": KIND_PAGES[doc.kind], "balance": balance, "has_payments": doc.amount_paid > 0,
        },
    )


@entity_required
@require_POST
def document_action(request, pk, action):
    doc = get_object_or_404(Document, pk=pk, entity=request.membership.entity)
    try:
        if action == "issue":
            services.issue_document(doc, request.user)
            messages.success(request, f"{doc} issued.")
        elif action == "void":
            services.void_document(doc, request.user)
            messages.success(request, f"{doc} voided and its journal reversed.")
        elif action == "delete":
            services.delete_draft(doc, request.user)
            messages.success(request, "Draft deleted.")
            return redirect(KIND_PAGES[doc.kind]["list"])
        else:
            raise ValidationError("Unknown action.")
    except (ValidationError, PermissionDenied) as exc:
        messages.error(request, _msgs(exc))
    return redirect("document_detail", pk=doc.pk)


@entity_required
@require_POST
def document_pay(request, pk):
    entity = request.membership.entity
    doc = get_object_or_404(Document, pk=pk, entity=entity)
    form = PaymentForm(request.POST, entity=entity)
    if not form.is_valid():
        messages.error(request, "Payment not recorded: " + "; ".join(f"{k}: {' '.join(v)}" for k, v in form.errors.items()))
        return redirect("document_detail", pk=doc.pk)
    d = form.cleaned_data
    try:
        services.record_payment(
            entity=entity, user=request.user, contact=doc.contact, currency=doc.currency, date=d["date"],
            kind=Payment.RECEIVED if doc.kind == Document.INVOICE else Payment.PAID,
            bank_account=d["bank_account"], allocations=[(doc, d["amount"])], reference=d["reference"], fx_rate=d["fx_rate"],
        )
        messages.success(request, "Payment recorded and posted.")
    except (ValidationError, PermissionDenied) as exc:
        messages.error(request, _msgs(exc))
    return redirect("document_detail", pk=doc.pk)


@entity_required
@require_POST
def payment_void(request, pk):
    payment = get_object_or_404(Payment.objects.prefetch_related("allocations__document"), pk=pk, entity=request.membership.entity)
    doc = payment.allocations.first().document
    try:
        services.void_payment(payment, request.user)
        messages.success(request, "Payment voided and its journal reversed.")
    except (ValidationError, PermissionDenied) as exc:
        messages.error(request, _msgs(exc))
    return redirect("document_detail", pk=doc.pk)


@entity_required
def contact_list(request):
    entity = request.membership.entity
    return render(request, "billing/contact_list.html", {"contacts": Contact.objects.filter(entity=entity)})


@entity_required
def contact_new(request):
    membership = request.membership
    if not membership.can_submit:
        raise PermissionDenied
    form = ContactForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        contact = form.save(commit=False)
        contact.entity = membership.entity
        if Contact.objects.filter(entity=contact.entity, name__iexact=contact.name).exists():
            form.add_error("name", "A contact with this name already exists.")
        else:
            contact.save()
            messages.success(request, f"{contact.name} added.")
            return redirect("contact_list")
    return render(request, "billing/contact_form.html", {"form": form})


@entity_required
def aging_report(request):
    entity = request.membership.entity
    kind = Document.BILL if request.GET.get("kind") == "bill" else Document.INVOICE
    rows, totals, grand = services.aging(entity, kind, timezone.localdate())
    return render(
        request, "billing/aging.html",
        {"rows": rows, "totals": totals, "grand": grand, "kind": kind, "page": KIND_PAGES[kind], "buckets": services.BUCKET_NAMES},
    )
